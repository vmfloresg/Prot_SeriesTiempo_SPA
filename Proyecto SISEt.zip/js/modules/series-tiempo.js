
/* =========================================================
   ESTADO DE LA APLICACIÓN
   ========================================================= */

let ts_series = [];
let ts_datos = [];

let ts_chart = null;


/* =========================================================
   INICIALIZACIÓN
   ========================================================= */


function ts_crudCrearRegistrosEjemplo() {
    const ahora = new Date();
    const fecha = dias => new Date(ahora.getTime() - dias * 86400000).toISOString();

    const ejemplos = [
        {
            id: "CS-0001",
            creadoEn: fecha(30), actualizadoEn: fecha(1), habilitado: true,
            titulo: { texto: "Recursos administrados por las AFORE", renglon: "1", alineacion: "center", sangria: "0" },
            configuracionSerie: { descripcion: "Recursos administrados por las AFORE al cierre de cada periodo.", decimales: 2, tipoCifra: "Saldo", periodicidad: "Mensual", periodoInicio: "2025-01", periodoFin: "2026-06", unidad: "Millones de pesos" },
            seriesDatos: [
                { id: 1, parentId: null, title: "Recursos administrados", indent: 0, afores: ["Azteca", "Banamex", "Coppel"] },
                { id: 2, parentId: 1, title: "Recursos por tipo de fondo", indent: 1, afores: ["Inbursa", "PensionISSSTE"] }
            ],
            siguienteSerieId: 3,
            notas: "Cifras ficticias utilizadas únicamente para demostración del prototipo.",
            fuente: "Datos ficticios - prototipo",
            seriesLegacy: [], datosLegacy: []
        },
        {
            id: "CS-0002",
            creadoEn: fecha(24), actualizadoEn: fecha(3), habilitado: true,
            titulo: { texto: "Número de cuentas administradas", renglon: "1", alineacion: "center", sangria: "0" },
            configuracionSerie: { descripcion: "Total de cuentas administradas por AFORE.", decimales: 0, tipoCifra: "Total", periodicidad: "Mensual", periodoInicio: "2025-01", periodoFin: "2026-06", unidad: "Cuentas" },
            seriesDatos: [
                { id: 1, parentId: null, title: "Cuentas registradas", indent: 0, afores: ["Profuturo", "SURA", "XXI Banorte"] },
                { id: 2, parentId: 1, title: "Cuentas asignadas", indent: 1, afores: ["Principal", "Invercap"] }
            ],
            siguienteSerieId: 3,
            notas: "Información de ejemplo para visualizar la estructura jerárquica.",
            fuente: "Datos ficticios - prototipo",
            seriesLegacy: [], datosLegacy: []
        },
        {
            id: "CS-0003",
            creadoEn: fecha(18), actualizadoEn: fecha(5), habilitado: true,
            titulo: { texto: "Rendimiento neto por AFORE", renglon: "1", alineacion: "center", sangria: "0" },
            configuracionSerie: { descripcion: "Indicadores ficticios de rendimiento neto por administradora.", decimales: 2, tipoCifra: "Porcentaje", periodicidad: "Trimestral", periodoInicio: "2025-01", periodoFin: "2026-06", unidad: "Porcentaje" },
            seriesDatos: [
                { id: 1, parentId: null, title: "Rendimiento neto", indent: 0, afores: ["Citibanamex", "Coppel", "Inbursa"] },
                { id: 2, parentId: null, title: "Rendimiento por horizonte", indent: 0, afores: ["Profuturo", "SURA"] }
            ],
            siguienteSerieId: 3,
            notas: "Porcentajes generados con fines ilustrativos.",
            fuente: "Datos ficticios - prototipo",
            seriesLegacy: [], datosLegacy: []
        }
    ];

    const registros = ts_crudLeerRegistros();
    if (!registros.length) {
        ts_crudPersistirRegistros(ejemplos);
        return;
    }

    // Si los registros ficticios ya existían de una versión anterior sin jerarquía,
    // se enriquecen sin sobrescribir registros reales creados por el usuario.
    let cambio = false;
    ejemplos.forEach(ejemplo => {
        const i = registros.findIndex(r => r.id === ejemplo.id);
        if (i >= 0 && (!Array.isArray(registros[i].seriesDatos) || registros[i].seriesDatos.length === 0)) {
            registros[i] = { ...registros[i], ...ejemplo, creadoEn: registros[i].creadoEn || ejemplo.creadoEn };
            cambio = true;
        }
    });
    if (cambio) ts_crudPersistirRegistros(registros);
}

document.addEventListener("DOMContentLoaded", () => {

    document
        .getElementById("titleIndent")
        .addEventListener("input", function () {

            document.getElementById("indentValue").textContent =
                this.value;

            ts_actualizarTitulo();

        });


    ts_actualizarVistaPrevia();

});


/* =========================================================
   TITULO
   ========================================================= */

function ts_actualizarTitulo() {

    const title =
        document.getElementById("chartTitle").value
        || "Evolución de las ts_series de tiempo";


    const alignment =
        document.getElementById("titleAlignment").value;


    const indent =
        document.getElementById("titleIndent").value;


    const row =
        parseInt(
            document.getElementById("titleRow").value
        ) || 1;


    const titleElement =
        document.getElementById("previewTitle");


    titleElement.textContent = title;

    titleElement.style.textAlign = alignment;

    titleElement.style.marginTop =
        `${(row - 1) * 10}px`;

    titleElement.style.paddingLeft =
        `${indent * 10}px`;
}


/* =========================================================
   AGREGAR SERIE
   ========================================================= */

function ts_agregarSerie() {

    const id =
        document.getElementById("seriesId").value.trim();

    const name =
        document.getElementById("seriesName").value.trim();

    const variable =
        document.getElementById("seriesVariable").value.trim();

    const unit =
        document.getElementById("seriesUnit").value;

    const frequency =
        document.getElementById("seriesFrequency").value;

    const start =
        document.getElementById("startPeriod").value;

    const end =
        document.getElementById("endPeriod").value;

    const source =
        document.getElementById("seriesSource").value.trim();


    if (!id || !name) {

        ts_mostrarMensaje(
            "Debe capturar el identificador y nombre de la serie.",
            "warning"
        );

        return;
    }


    const nuevaSerie = {

        id,
        name,
        variable,
        unit,
        frequency,
        start,
        end,
        source

    };


    ts_series.push(nuevaSerie);


    ts_renderizarSeries();

    ts_actualizarVistaPrevia();


    limpiarFormularioSerie();
}


/* =========================================================
   RENDERIZAR SERIES
   ========================================================= */

function ts_renderizarSeries() {

    const container =
        document.getElementById("seriesContainer");


    if (ts_series.length === 0) {

        container.innerHTML = `
            <div class="empty-message">
                No existen ts_series configuradas.
            </div>
        `;

        return;
    }


    container.innerHTML = "";


    ts_series.forEach((serie, index) => {

        const element =
            document.createElement("div");


        element.className = "ts_series-item";


        element.innerHTML = `

            <div class="d-flex justify-content-between">

                <div>

                    <div class="ts_series-item-title">
                        ${serie.name}
                    </div>

                    <div class="ts_series-item-meta">
                        ${serie.id} · ${serie.frequency}
                    </div>

                </div>

                <span class="badge text-bg-light">
                    ${serie.unit}
                </span>

            </div>


            <div class="ts_series-actions">

                <button
                    class="btn btn-outline-danger btn-sm"
                    onclick="ts_eliminarSerie(${index})">

                    <i class="bi bi-trash"></i>

                </button>

            </div>

        `;


        container.appendChild(element);

    });

}


/* =========================================================
   ELIMINAR SERIE
   ========================================================= */

function ts_eliminarSerie(index) {

    ts_series.splice(index, 1);

    ts_renderizarSeries();

    ts_actualizarVistaPrevia();

}


/* =========================================================
   AGREGAR DATO
   ========================================================= */

function ts_agregarDato() {

    const period =
        document.getElementById("dataPeriod").value;

    const value =
        document.getElementById("dataValue").value;


    if (!period || value === "") {

        ts_mostrarMensaje(
            "Debe indicar el periodo y el valor.",
            "warning"
        );

        return;
    }


    ts_datos.push({

        period,
        value: Number(value)

    });


    ts_datos.sort(
        (a, b) =>
            a.period.localeCompare(b.period)
    );


    ts_renderizarDatos();

    ts_actualizarVistaPrevia();


    document.getElementById("dataPeriod").value = "";

    document.getElementById("dataValue").value = "";

}


/* =========================================================
   RENDERIZAR DATOS
   ========================================================= */

function ts_renderizarDatos() {

    const tbody =
        document.getElementById("dataTableBody");


    tbody.innerHTML = "";


    ts_datos.forEach((dato, index) => {

        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td>
                ${ts_formatearPeriodo(dato.period)}
            </td>

            <td class="text-end">
                ${dato.value.toLocaleString(
            "es-MX"
        )}
            </td>

            <td class="text-end">

                <button
                    class="btn btn-sm btn-link text-danger"
                    onclick="ts_eliminarDato(${index})">

                    <i class="bi bi-trash"></i>

                </button>

            </td>

        `;


        tbody.appendChild(row);

    });

}


/* =========================================================
   ELIMINAR DATO
   ========================================================= */

function ts_eliminarDato(index) {

    ts_datos.splice(index, 1);

    ts_renderizarDatos();

    ts_actualizarVistaPrevia();

}


/* =========================================================
   ACTUALIZAR VISTA PREVIA
   ========================================================= */

function ts_actualizarVistaPrevia() {

    ts_actualizarTitulo();


    const frecuencia =
        document.getElementById(
            "seriesFrequency"
        ).value;


    const fuente =
        document.getElementById(
            "seriesSource"
        ).value || "—";


    document.getElementById("previewMeta").innerHTML = `

        <span>
            <i class="bi bi-calendar3"></i>
            Periodicidad: ${frecuencia}
        </span>

        <span>
            <i class="bi bi-database"></i>
            Fuente: ${fuente}
        </span>

    `;


    ts_actualizarVistaPreviaSeries();

    ts_actualizarNotas();

}


/* =========================================================
   GRAFICA
   ========================================================= */

function ts_actualizarGrafica() {

    const canvas =
        document.getElementById(
            "timeSeriesChart"
        );

    if (!canvas || typeof Chart === "undefined") {
        return;
    }

    if (ts_chart) {

        ts_chart.destroy();

    }


    let labels = [];

    let values = [];


    if (ts_datos.length > 0) {

        labels =
            ts_datos.map(
                dato => ts_formatearPeriodo(dato.period)
            );

        values =
            ts_datos.map(
                dato => dato.value
            );

    } else {

        labels = [
            "Ene 2025",
            "Feb 2025",
            "Mar 2025",
            "Abr 2025",
            "May 2025",
            "Jun 2025"
        ];


        values = [
            820,
            850,
            875,
            910,
            950,
            980
        ];

    }


    const datasets = [];


    if (ts_series.length === 0) {

        datasets.push({

            label: "Serie de ejemplo",

            data: values,

            borderWidth: 2,

            tension: 0.35,

            pointRadius: 3,

            fill: false

        });

    } else {

        ts_series.forEach((serie, index) => {

            let serieData;


            if (index === 0) {

                serieData = values;

            } else {

                serieData =
                    values.map(
                        value =>
                            value *
                            (1 + index * 0.08)
                    );

            }


            datasets.push({

                label: serie.name,

                data: serieData,

                borderWidth: 2,

                tension: 0.35,

                pointRadius: 3,

                fill: false

            });

        });

    }


    ts_chart = new Chart(canvas, {

        type: "line",

        data: {

            labels,

            datasets

        },

        options: {

            responsive: true,

            maintainAspectRatio: false,

            interaction: {

                intersect: false,

                mode: "index"

            },

            plugins: {

                legend: {

                    position: "bottom",

                    labels: {

                        boxWidth: 12,

                        font: {

                            size: 11

                        }

                    }

                },

                tooltip: {

                    callbacks: {

                        label: function (context) {

                            return `${context.dataset.label}: ${Number(
                                context.raw
                            ).toLocaleString("es-MX")
                                }`;

                        }

                    }

                }

            },

            scales: {

                x: {

                    grid: {

                        display: false

                    },

                    ticks: {

                        font: {

                            size: 10

                        }

                    }

                },

                y: {

                    beginAtZero: false,

                    ticks: {

                        font: {

                            size: 10

                        },

                        callback: function (value) {

                            return value.toLocaleString(
                                "es-MX"
                            );

                        }

                    }

                }

            }

        }

    });

}


/* =========================================================
   NOTAS
   ========================================================= */

function ts_actualizarNotas() {

    const notes =
        document.getElementById(
            "chartNotes"
        ).value.trim();


    const source =
        document.getElementById(
            "chartSource"
        ).value.trim();


    const notesElement =
        document.getElementById(
            "previewNotes"
        );


    const footer =
        document.getElementById(
            "previewFooter"
        );


    notesElement.innerHTML = `

        <div class="notes-title">
            Notas
        </div>

        <p>
            ${notes ||
        "Configure las notas y fuentes desde el panel izquierdo."
        }
        </p>

    `;


    footer.textContent =
        `Fuente: ${source || "—"}`;

}


/* =========================================================
   VISTA COMPLETA
   ========================================================= */

function ts_vistaCompleta() {

    const documentPreview =
        document.getElementById(
            "previewDocument"
        );

    const content =
        document.getElementById(
            "fullPreviewContent"
        );

    const modalElement =
        document.getElementById(
            "fullPreviewModal"
        );

    if (!documentPreview || !content || !modalElement) {
        return;
    }

    /*
     * La Vista completa vive fuera de #tables. Por esa razón no se debe
     * copiar el HTML con outerHTML y esperar que herede los estilos del
     * módulo. Creamos una copia limpia, sin IDs duplicados, y la montamos
     * en un contenedor propio que cuenta con estilos equivalentes.
     */
    const clone = documentPreview.cloneNode(true);
    clone.removeAttribute("id");
    clone.classList.add("full-preview-document");

    clone.querySelectorAll("[id]").forEach(element => {
        element.removeAttribute("id");
    });


    content.replaceChildren(clone);

    const modal =
        bootstrap.Modal.getOrCreateInstance(
            modalElement
        );

    modal.show();

}


/* =========================================================
   GUARDAR CONFIGURACION
   ========================================================= */

function ts_guardarConfiguracion() {
    ts_crudGuardar();
}



/* =========================================================
   RESTABLECER
   ========================================================= */

// function limpiarConfiguracion() {

//     if (
//         !confirm(
//             "¿Desea eliminar toda la configuración actual?"
//         )
//     ) {

//         return;

//     }


//     ts_series = [];

//     ts_datos = [];


//     document.querySelectorAll(
//         "input, textarea"
//     ).forEach(element => {

//         if (
//             element.type !== "range" &&
//             element.type !== "number"
//         ) {

//             element.value = "";

//         }

//     });


//     document.getElementById(
//         "titleRow"
//     ).value = 1;


//     document.getElementById(
//         "titleIndent"
//     ).value = 0;


//     document.getElementById(
//         "indentValue"
//     ).textContent = "0";


//     document.getElementById(
//         "titleAlignment"
//     ).value = "center";


//     ts_renderizarSeries();

//     ts_renderizarDatos();

//     ts_actualizarVistaPrevia();

// }


// /* =========================================================
//    FORMULARIO DE SERIE
//    ========================================================= */

// function limpiarFormularioSerie() {

//     document.getElementById(
//         "seriesId"
//     ).value = "";

//     document.getElementById(
//         "seriesName"
//     ).value = "";

//     document.getElementById(
//         "seriesVariable"
//     ).value = "";

//     document.getElementById(
//         "seriesSource"
//     ).value = "";

// }


/* =========================================================
   UTILIDADES
   ========================================================= */

function ts_formatearPeriodo(periodo) {

    if (!periodo) {
        return "";
    }


    const partes =
        periodo.split("-");


    const meses = [

        "Ene",
        "Feb",
        "Mar",
        "Abr",
        "May",
        "Jun",
        "Jul",
        "Ago",
        "Sep",
        "Oct",
        "Nov",
        "Dic"

    ];


    const año = partes[0];

    const mes =
        parseInt(partes[1]) - 1;


    return `${meses[mes]} ${año}`;

}


/* =========================================================
   MENSAJES
   ========================================================= */

function ts_mostrarMensaje(
    mensaje,
    tipo
) {

    const alert =
        document.createElement(
            "div"
        );


    alert.className =
        `alert alert-${tipo} position-fixed shadow`;

    alert.style.top = "90px";

    alert.style.right = "25px";

    alert.style.zIndex = "9999";

    alert.style.fontSize = "12px";


    alert.innerHTML = `

        <i class="bi bi-info-circle"></i>

        ${mensaje}

    `;


    document.body.appendChild(alert);


    setTimeout(() => {

        alert.remove();

    }, 3000);

}


/* ========================================================= 
    CONFIGURACIÓN GENERAL DE LA SERIE 
========================================================= */

let ts_configuracionSerie = {
    descripcion: "",
    decimales: 2,
    tipoCifra: "",
    periodicidad: "",
    periodoInicio: "",
    periodoFin: "",
    unidad: ""
};

/* ========================================================= 
    AGREGAR CONFIGURACIÓN A PREVISUALIZACIÓN 
========================================================= */

function ts_agregarConfiguracionSerie() {

    ts_configuracionSerie = {
        descripcion:
            document.getElementById("seriesDescription").value.trim(),
        decimales:
            document.getElementById("decimalPlaces").value,
        tipoCifra:
            document.getElementById("figureType").value,
        periodicidad:
            document.getElementById("seriesFrequency").value,
        periodoInicio:
            document.getElementById("availablePeriodStart").value,
        periodoFin:
            document.getElementById("availablePeriodEnd").value,
        unidad:
            document.getElementById("seriesUnit").value
    };

    ts_actualizarInformacionSerie();

    ts_mostrarMensaje("La configuración de la serie fue enviada a la previsualización.", "success");
}

/* ========================================================= 
    ACTUALIZAR INFORMACIÓN EN PREVISUALIZACIÓN 
========================================================= */

function ts_actualizarInformacionSerie() {

    const existing = document.getElementById("seriesInformation");

    if (existing) {
        existing.remove();
    }

    const chartTitle = document.getElementById("previewTitle");
    if (!chartTitle) {
        return;
    }

    const inicio = ts_formatearPeriodo(ts_configuracionSerie.periodoInicio);
    const fin = ts_formatearPeriodo(ts_configuracionSerie.periodoFin);
    const periodoDisponible =
        inicio === "—" && fin === "—"
            ? "—"
            : `${inicio} – ${fin}`;

    const information = document.createElement("section");
    information.id = "seriesInformation";
    information.className = "series-information";
    information.setAttribute("aria-label", "Información general de la serie de tiempo");

    information.innerHTML = `
        <div class="series-information-title">
            <i class="bi bi-info-circle"></i>
            <span>Información del cuadro / serie</span>
        </div>

        <div class="series-information-grid">
            <div class="series-information-item series-information-description">
                <div class="series-information-label">Descripción</div>
                <div class="series-information-value">${ts_escapeHtml(ts_configuracionSerie.descripcion || "—")}</div>
            </div>

            <div class="series-information-item">
                <div class="series-information-label">Número de decimales</div>
                <div class="series-information-value">${ts_escapeHtml(String(ts_configuracionSerie.decimales ?? "—"))}</div>
            </div>

            <div class="series-information-item">
                <div class="series-information-label">Tipo de cifra</div>
                <div class="series-information-value">${ts_escapeHtml(ts_configuracionSerie.tipoCifra || "—")}</div>
            </div>

            <div class="series-information-item">
                <div class="series-information-label">Periodicidad</div>
                <div class="series-information-value">${ts_escapeHtml(ts_configuracionSerie.periodicidad || "—")}</div>
            </div>

            <div class="series-information-item series-information-period">
                <div class="series-information-label">Periodo requerido</div>
                <div class="series-information-value">${ts_escapeHtml(periodoDisponible)}</div>
            </div>

            <div class="series-information-item">
                <div class="series-information-label">Unidad de medida</div>
                <div class="series-information-value">${ts_escapeHtml(ts_configuracionSerie.unidad || "—")}</div>
            </div>
        </div>
    `;

    /* La información general se coloca inmediatamente después del título. */
    chartTitle.insertAdjacentElement("afterend", information);
}


/* ========================================================= 
    FORMATEAR PERIODO 
========================================================= */

function ts_formatearPeriodo(periodo) {

    if (!periodo) {
        return "—";
    }

    const partes = periodo.split("-");

    if (partes.length < 2) {
        return periodo;
    }

    const meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
    const año = partes[0];
    const mes = parseInt(partes[1], 10) - 1; if (mes < 0 || mes > 11) { return periodo; } return `${meses[mes]} ${año}`;

}


/* =========================================================
   SERIES JERÁRQUICAS
   ========================================================= */

let ts_seriesDatos = [];
// Relaciones Serie de tiempo → Cuadros consumidores.
let ts_vinculosSeriesCuadros = {};

let ts_siguienteSerieId = 1;


/* =========================================================
   EDITOR SEGURO DE SERIES DE DATOS
   Los cambios se realizan sobre un borrador y sólo pasan al
   cuadro al pulsar "Guardar cambios".
   ========================================================= */

let ts_periodosDatos = [
    { id: "p1", label: "JUNIO 2025" },
    { id: "p2", label: "MAYO 2026" },
    { id: "p3", label: "JUNIO 2026" }
];
let ts_valoresDatos = {};
let ts_editorDatosActivo = false;
let ts_editorDatosDraft = null;
let ts_editorDatosBase = null;
let ts_editorDatosUndo = [];
let ts_editorDatosRedo = [];

function ts_datosClave(serieId, afore, periodoId) {
    return `${serieId}::${afore}::${periodoId}`;
}

function ts_datosClonar(valor) {
    return JSON.parse(JSON.stringify(valor));
}

function ts_datosValorInicial(serieId, afore, periodoId, series = ts_seriesDatos, periodos = ts_periodosDatos) {
    const serie = series.find(s => Number(s.id) === Number(serieId));
    if (!serie) return null;
    const ai = Math.max(0, serie.afores.indexOf(afore));
    const pi = Math.max(0, periodos.findIndex(p => p.id === periodoId));
    const base = ts_obtenerValorEjemplo(Number(serieId), ai);
    const factores = [1, 1.035, 1.041];
    const factor = factores[pi] ?? (1 + pi * 0.025);
    return Number((base * factor).toFixed(2));
}

function ts_datosAsegurarValores(series = ts_seriesDatos, periodos = ts_periodosDatos, valores = ts_valoresDatos) {
    series.forEach(serie => {
        (serie.afores || []).forEach(afore => {
            periodos.forEach(periodo => {
                const key = ts_datosClave(serie.id, afore, periodo.id);
                if (!(key in valores)) valores[key] = ts_datosValorInicial(serie.id, afore, periodo.id, series, periodos);
            });
        });
    });
    return valores;
}

function ts_editorDatosSnapshot() {
    return ts_datosClonar(ts_editorDatosDraft);
}

function ts_editorDatosRegistrarCambio() {
    if (!ts_editorDatosActivo) return;
    ts_editorDatosUndo.push(ts_editorDatosSnapshot());
    if (ts_editorDatosUndo.length > 50) ts_editorDatosUndo.shift();
    ts_editorDatosRedo = [];
}

function ts_editorDatosIniciar() {
    if (!ts_seriesDatos.length) {
        ts_mostrarMensaje("Agregue al menos una serie antes de editar sus datos.", "warning");
        return;
    }
    ts_datosAsegurarValores();
    ts_editorDatosActivo = true;
    ts_editorDatosDraft = {
        series: ts_datosClonar(ts_seriesDatos),
        periodos: ts_datosClonar(ts_periodosDatos),
        valores: ts_datosClonar(ts_valoresDatos)
    };
    ts_editorDatosBase = ts_datosClonar(ts_editorDatosDraft);
    ts_editorDatosUndo = [];
    ts_editorDatosRedo = [];
    ts_editorDatosRender();

    const modalEl = document.getElementById("tsDataEditorModal");
    if (modalEl && window.bootstrap?.Modal) {
        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }
}

function ts_editorDatosCancelar() {
    if (!ts_editorDatosActivo) return;
    const cambios = ts_editorDatosContarCambios();
    if (cambios.total && !confirm(`Hay ${cambios.total} cambio(s) sin guardar. ¿Desea descartarlos?`)) return;
    ts_editorDatosCerrar();
    ts_mostrarMensaje("Los cambios de datos fueron cancelados.", "info");
}

function ts_editorDatosCerrar() {
    ts_editorDatosActivo = false;
    ts_editorDatosDraft = null;
    ts_editorDatosBase = null;
    ts_editorDatosUndo = [];
    ts_editorDatosRedo = [];

    const modalEl = document.getElementById("tsDataEditorModal");
    if (modalEl && window.bootstrap?.Modal) {
        bootstrap.Modal.getOrCreateInstance(modalEl).hide();
    }
}

function ts_editorDatosDeshacer() {
    if (!ts_editorDatosUndo.length) return;
    ts_editorDatosRedo.push(ts_editorDatosSnapshot());
    ts_editorDatosDraft = ts_editorDatosUndo.pop();
    ts_editorDatosRender();
}

function ts_editorDatosRehacer() {
    if (!ts_editorDatosRedo.length) return;
    ts_editorDatosUndo.push(ts_editorDatosSnapshot());
    ts_editorDatosDraft = ts_editorDatosRedo.pop();
    ts_editorDatosRender();
}

function ts_editorDatosQuitarAfore(serieId, afore) {
    if (!ts_editorDatosActivo) return;
    const serie = ts_editorDatosDraft.series.find(s => Number(s.id) === Number(serieId));
    if (!serie) return;
    if (!confirm(`¿Quitar “${afore}” de la serie “${serie.title}”?\n\nSus valores dejarán de formar parte del cuadro. Puede deshacer este cambio antes de guardar.`)) return;
    ts_editorDatosRegistrarCambio();
    serie.afores = serie.afores.filter(a => a !== afore);
    ts_editorDatosDraft.periodos.forEach(p => delete ts_editorDatosDraft.valores[ts_datosClave(serieId, afore, p.id)]);
    ts_editorDatosRender();
}

function ts_editorDatosCatalogoAfores() {
    const desdeSelectorPrincipal = Array.from(document.querySelectorAll(".afore-check"))
        .map(c => String(c.value || "").trim())
        .filter(Boolean);

    const catalogoBase = desdeSelectorPrincipal.length ? desdeSelectorPrincipal : [
        "Azteca", "Banamex", "Coppel", "Inbursa", "Invercap",
        "PensionISSSTE", "Principal", "Profuturo", "SURA", "XXI Banorte"
    ];

    return [...new Set(catalogoBase)];
}

function ts_editorDatosActualizarAforesDisponibles() {
    if (!ts_editorDatosDraft) return;
    const serieSelect = document.getElementById("tsDataAddAforeSerie");
    const aforeSelect = document.getElementById("tsDataAddAforeNombre");
    if (!serieSelect || !aforeSelect) return;

    const serie = ts_editorDatosDraft.series.find(s => Number(s.id) === Number(serieSelect.value));
    const usadas = new Set((serie?.afores || []).map(a => String(a).trim().toLowerCase()));
    const disponibles = ts_editorDatosCatalogoAfores().filter(a => !usadas.has(a.toLowerCase()));

    aforeSelect.innerHTML = `<option value="">Seleccione una AFORE...</option>${disponibles.map(a =>
        `<option value="${ts_escapeHtml(a)}">${ts_escapeHtml(a)}</option>`
    ).join("")}`;

    if (!disponibles.length) {
        aforeSelect.innerHTML = '<option value="">No hay AFORE disponibles para esta serie</option>';
        aforeSelect.disabled = true;
    } else {
        aforeSelect.disabled = false;
    }
}

function ts_editorDatosMostrarAgregarAfore() {
    if (!ts_editorDatosActivo || !ts_editorDatosDraft) return;
    const panel = document.getElementById("tsDataAddAforePanel");
    const select = document.getElementById("tsDataAddAforeSerie");
    const input = document.getElementById("tsDataAddAforeNombre");
    if (!panel || !select || !input) return;

    const opciones = [];
    const agregarOpcion = (serie) => {
        const prefijo = "— ".repeat(Math.max(0, Number(serie.indent || 0)));
        opciones.push(`<option value="${serie.id}">${ts_escapeHtml(prefijo + serie.title)}</option>`);
        ts_editorDatosDraft.series
            .filter(s => Number(s.parentId) === Number(serie.id))
            .forEach(agregarOpcion);
    };
    ts_editorDatosDraft.series.filter(s => s.parentId === null).forEach(agregarOpcion);
    select.innerHTML = opciones.join("");
    panel.classList.remove("d-none");
    ts_editorDatosActualizarAforesDisponibles();
    setTimeout(() => input.focus(), 50);
}

function ts_editorDatosOcultarAgregarAfore() {
    document.getElementById("tsDataAddAforePanel")?.classList.add("d-none");
    const input = document.getElementById("tsDataAddAforeNombre");
    if (input) input.value = "";
}

function ts_editorDatosAgregarAfore() {
    if (!ts_editorDatosActivo || !ts_editorDatosDraft) return;
    const select = document.getElementById("tsDataAddAforeSerie");
    const input = document.getElementById("tsDataAddAforeNombre");
    if (!select || !input) return;

    const serieId = Number(select.value);
    const nombre = String(input.value || "").trim();
    if (!nombre) {
        ts_mostrarMensaje("Seleccione la AFORE que desea agregar.", "warning");
        input.focus();
        return;
    }

    const serie = ts_editorDatosDraft.series.find(s => Number(s.id) === serieId);
    if (!serie) return;
    serie.afores = Array.isArray(serie.afores) ? serie.afores : [];

    const existe = serie.afores.some(a => String(a).trim().toLowerCase() === nombre.toLowerCase());
    if (existe) {
        ts_mostrarMensaje(`La AFORE “${nombre}” ya existe dentro de la serie “${serie.title}”.`, "warning");
        input.focus();
        return;
    }

    ts_editorDatosRegistrarCambio();
    serie.afores.push(nombre);
    ts_editorDatosDraft.periodos.forEach(p => {
        ts_editorDatosDraft.valores[ts_datosClave(serie.id, nombre, p.id)] = null;
    });

    ts_editorDatosOcultarAgregarAfore();
    ts_editorDatosRender();
    ts_mostrarMensaje(`AFORE “${nombre}” agregada a “${serie.title}”. Guarde los cambios para aplicarla al cuadro.`, "success");
}

function ts_editorDatosEliminarColumna(periodoId) {
    if (!ts_editorDatosActivo) return;
    if (ts_editorDatosDraft.periodos.length <= 1) {
        ts_mostrarMensaje("Debe conservar al menos una columna de datos.", "warning");
        return;
    }
    const periodo = ts_editorDatosDraft.periodos.find(p => p.id === periodoId);
    if (!periodo) return;
    let valores = 0;
    ts_editorDatosDraft.series.forEach(s => valores += (s.afores || []).length);
    if (!confirm(`¿Eliminar la columna “${periodo.label}”?\n\nSe retirarán ${valores} valor(es) asociados. Puede deshacer el cambio antes de guardar.`)) return;
    ts_editorDatosRegistrarCambio();
    ts_editorDatosDraft.periodos = ts_editorDatosDraft.periodos.filter(p => p.id !== periodoId);
    Object.keys(ts_editorDatosDraft.valores).forEach(k => {
        if (k.endsWith(`::${periodoId}`)) delete ts_editorDatosDraft.valores[k];
    });
    ts_editorDatosRender();
}

function ts_editorDatosAgregarColumna() {
    if (!ts_editorDatosActivo) return;
    const label = prompt("Nombre de la nueva columna o periodo:", "JULIO 2026");
    if (!label || !label.trim()) return;
    ts_editorDatosRegistrarCambio();
    const id = `p${Date.now()}`;
    ts_editorDatosDraft.periodos.push({ id, label: label.trim().toUpperCase() });
    ts_editorDatosDraft.series.forEach(s => (s.afores || []).forEach(a => {
        ts_editorDatosDraft.valores[ts_datosClave(s.id, a, id)] = null;
    }));
    ts_editorDatosRender();
}

function ts_editorDatosFormatearMoneda(value) {
    if (value === null || value === undefined || value === "") return "";
    const numero = typeof value === "number" ? value : Number(String(value).replace(/[$,\s]/g, ""));
    if (!Number.isFinite(numero)) return String(value);
    return new Intl.NumberFormat("es-MX", {
        style: "currency",
        currency: "MXN",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(numero);
}

function ts_editorDatosCambiarCelda(serieId, afore, periodoId, input) {
    if (!ts_editorDatosActivo) return;
    const key = ts_datosClave(serieId, afore, periodoId);
    const anterior = ts_editorDatosDraft.valores[key];
    const texto = String(input.value ?? "").trim();
    let nuevo = null;
    if (texto !== "") {
        const normalizado = texto.replace(/[^0-9.\-]/g, "");
        nuevo = normalizado !== "" && Number.isFinite(Number(normalizado)) ? Number(normalizado) : texto;
    }
    if (String(anterior ?? "") === String(nuevo ?? "")) {
        input.value = ts_editorDatosFormatearMoneda(anterior);
        return;
    }
    ts_editorDatosRegistrarCambio();
    ts_editorDatosDraft.valores[key] = nuevo;
    ts_editorDatosRender();
}

function ts_editorDatosLimpiarCelda(serieId, afore, periodoId) {
    if (!ts_editorDatosActivo) return;
    const key = ts_datosClave(serieId, afore, periodoId);
    if (ts_editorDatosDraft.valores[key] === null || ts_editorDatosDraft.valores[key] === "") return;
    ts_editorDatosRegistrarCambio();
    ts_editorDatosDraft.valores[key] = null;
    ts_editorDatosRender();
}

function ts_editorDatosContarCambios() {
    if (!ts_editorDatosBase || !ts_editorDatosDraft) return { total: 0, afores: 0, aforesAgregadas: 0, columnas: 0, agregadas: 0, celdas: 0 };
    const baseP = new Set(ts_editorDatosBase.periodos.map(p => p.id));
    const draftP = new Set(ts_editorDatosDraft.periodos.map(p => p.id));
    const columnas = [...baseP].filter(id => !draftP.has(id)).length;
    const agregadas = [...draftP].filter(id => !baseP.has(id)).length;
    let afores = 0;
    let aforesAgregadas = 0;

    ts_editorDatosBase.series.forEach(bs => {
        const ds = ts_editorDatosDraft.series.find(s => Number(s.id) === Number(bs.id));
        const actuales = new Set((ds?.afores || []).map(a => String(a).toLowerCase()));
        afores += (bs.afores || []).filter(a => !actuales.has(String(a).toLowerCase())).length;
    });
    ts_editorDatosDraft.series.forEach(ds => {
        const bs = ts_editorDatosBase.series.find(s => Number(s.id) === Number(ds.id));
        const originales = new Set((bs?.afores || []).map(a => String(a).toLowerCase()));
        aforesAgregadas += (ds.afores || []).filter(a => !originales.has(String(a).toLowerCase())).length;
    });

    const keys = new Set([...Object.keys(ts_editorDatosBase.valores), ...Object.keys(ts_editorDatosDraft.valores)]);
    let celdas = 0;
    keys.forEach(k => {
        if (JSON.stringify(ts_editorDatosBase.valores[k] ?? null) !== JSON.stringify(ts_editorDatosDraft.valores[k] ?? null)) celdas++;
    });
    return { total: columnas + agregadas + afores + aforesAgregadas + celdas, afores, aforesAgregadas, columnas, agregadas, celdas };
}

function ts_editorDatosGuardar() {
    if (!ts_editorDatosActivo) return;
    const c = ts_editorDatosContarCambios();
    if (!c.total) {
        ts_editorDatosCerrar();
        ts_mostrarMensaje("No había cambios de datos por guardar.", "info");
        return;
    }
    const resumen = [
        c.afores ? `${c.afores} AFORE(s) retirada(s) de series` : null,
        c.aforesAgregadas ? `${c.aforesAgregadas} AFORE(s) agregada(s) a series` : null,
        c.columnas ? `${c.columnas} columna(s) eliminada(s)` : null,
        c.agregadas ? `${c.agregadas} columna(s) agregada(s)` : null,
        c.celdas ? `${c.celdas} valor(es) modificado(s) o limpiado(s)` : null
    ].filter(Boolean).join("\n• ");
    if (!confirm(`Guardar modificaciones de Series de datos:\n\n• ${resumen}\n\nLos cambios quedarán aplicados al cuadro actual.`)) return;
    ts_seriesDatos = ts_datosClonar(ts_editorDatosDraft.series);
    ts_periodosDatos = ts_datosClonar(ts_editorDatosDraft.periodos);
    ts_valoresDatos = ts_datosClonar(ts_editorDatosDraft.valores);
    ts_editorDatosCerrar();
    ts_renderizarSeriesConfiguradas();
    ts_actualizarCatalogoSeriesPadre();
    ts_actualizarVistaPreviaSeries();
    ts_mostrarMensaje("Cambios de Series de datos guardados correctamente.", "success");
}

function ts_editorDatosRender() {
    if (!ts_editorDatosActivo || !ts_editorDatosDraft) return;
    const head = document.getElementById("tsDataEditorHead");
    const body = document.getElementById("tsDataEditorBody");
    if (!head || !body) return;
    const d = ts_editorDatosDraft;
    head.innerHTML = `<tr><th class="ts-data-concept-col">Serie / AFORE</th>${d.periodos.map(p => `
        <th class="text-center ts-data-period-col">
            <div class="d-flex align-items-center justify-content-center gap-1">
                <span>${ts_escapeHtml(p.label)}</span>
                <button type="button" class="btn btn-link btn-sm text-danger p-0 ts-data-col-delete" title="Eliminar columna" onclick="ts_editorDatosEliminarColumna('${p.id}')"><i class="bi bi-trash3"></i></button>
            </div>
        </th>`).join("")}<th class="text-center ts-data-actions-col">Acciones</th></tr>`;

    let html = "";
    const renderSerie = (serie) => {
        html += `<tr class="ts-data-series-row"><td colspan="${d.periodos.length + 2}" style="padding-left:${serie.indent * 18 + 10}px"><i class="bi bi-diagram-3 me-2"></i><strong>${ts_escapeHtml(serie.title)}</strong><span class="badge text-bg-light ms-2">${(serie.afores || []).length} AFORE(s)</span></td></tr>`;
        (serie.afores || []).forEach(afore => {
            html += `<tr><td style="padding-left:${(serie.indent + 1) * 18 + 10}px"><span class="text-muted me-1">↳</span>${ts_escapeHtml(afore)}</td>`;
            d.periodos.forEach(p => {
                const key = ts_datosClave(serie.id, afore, p.id);
                const value = d.valores[key];
                const display = value === null || value === undefined ? "" : ts_editorDatosFormatearMoneda(value);
                html += `<td class="ts-data-cell"><div class="input-group input-group-sm ts-currency-input-group"><span class="input-group-text ts-currency-prefix" aria-hidden="true">MXN</span><input class="form-control text-end ts-data-cell-input ${display === "" ? "is-empty" : ""}" inputmode="decimal" autocomplete="off" value="${ts_escapeHtml(String(display))}" aria-label="Valor monetario ${ts_escapeHtml(afore)} ${ts_escapeHtml(p.label)}" onchange="ts_editorDatosCambiarCelda(${serie.id}, '${String(afore).replace(/'/g,"\\'")}', '${p.id}', this)"><button class="btn btn-outline-secondary" type="button" title="Limpiar valor" aria-label="Limpiar valor" onclick="ts_editorDatosLimpiarCelda(${serie.id}, '${String(afore).replace(/'/g,"\\'")}', '${p.id}')"><i class="bi bi-x-lg"></i></button></div></td>`;
            });
            html += `<td class="text-center"><button type="button" class="btn btn-sm btn-outline-danger" onclick="ts_editorDatosQuitarAfore(${serie.id}, '${String(afore).replace(/'/g,"\\'")}')" title="Quitar esta AFORE de la serie"><i class="bi bi-trash3 me-1"></i>Quitar</button></td></tr>`;
        });
        d.series.filter(s => Number(s.parentId) === Number(serie.id)).forEach(renderSerie);
    };
    d.series.filter(s => s.parentId === null).forEach(renderSerie);
    body.innerHTML = html || `<tr><td colspan="${d.periodos.length + 2}" class="text-center text-muted py-4">No hay datos para editar.</td></tr>`;

    const c = ts_editorDatosContarCambios();
    const badge = document.getElementById("tsDataPendingBadge");
    if (badge) badge.textContent = `${c.total} cambio${c.total === 1 ? "" : "s"} pendiente${c.total === 1 ? "" : "s"}`;
    const undo = document.getElementById("tsDataUndoBtn");
    const redo = document.getElementById("tsDataRedoBtn");
    if (undo) undo.disabled = !ts_editorDatosUndo.length;
    if (redo) redo.disabled = !ts_editorDatosRedo.length;
}


/* =========================================================
   ACTUALIZAR SANGRIA
   ========================================================= */

document
    .getElementById("dataSeriesIndent")
    .addEventListener("input", function () {

        document.getElementById(
            "dataSeriesIndentValue"
        ).textContent = this.value;

    });


/* =========================================================
   OBTENER AFORES SELECCIONADAS
   ========================================================= */

function ts_obtenerAforesSeleccionadas() {

    const checks =
        document.querySelectorAll(
            ".afore-check:checked"
        );


    return Array.from(checks)
        .map(check => check.value);

}


/* =========================================================
   ACTUALIZAR TEXTO DEL SELECTOR
   ========================================================= */

document.addEventListener(
    "change",
    function (event) {

        if (
            event.target.classList.contains(
                "afore-check"
            )
        ) {

            ts_actualizarTextoAfores();

        }

    }
);


/* =========================================================
   SELECTOR AFORE - CONTROL PROPIO PARA LA SPA
   ========================================================= */

(function ts_inicializarSelectorAfores() {
    const button = document.getElementById("aforesSelectorButton");
    const menu = document.getElementById("aforesDropdown");

    if (!button || !menu || button.dataset.tsInitialized === "1") {
        return;
    }

    button.dataset.tsInitialized = "1";

    const cerrar = () => {
        menu.classList.remove("ts-show");
        button.classList.remove("show");
        button.setAttribute("aria-expanded", "false");
    };

    const abrir = () => {
        menu.classList.add("ts-show");
        button.classList.add("show");
        button.setAttribute("aria-expanded", "true");
    };

    button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        if (menu.classList.contains("ts-show")) {
            cerrar();
        } else {
            abrir();
        }
    });

    menu.addEventListener("click", function (event) {
        // Mantener el menú abierto mientras se seleccionan varias AFORE.
        event.stopPropagation();
    });

    document.addEventListener("click", function () {
        cerrar();
    });
})();

function ts_actualizarTextoAfores() {

    const afores =
        ts_obtenerAforesSeleccionadas();


    const text =
        document.getElementById(
            "selectedAforesText"
        );


    if (afores.length === 0) {

        text.textContent =
            "Seleccionar AFORE";

        return;

    }


    if (afores.length === 10) {

        text.textContent =
            "Todas las AFORE seleccionadas";

        return;

    }


    text.textContent =
        `${afores.length} AFORE seleccionadas`;

}


/* =========================================================
   SELECCIONAR TODAS
   ========================================================= */

function ts_seleccionarTodasAfores() {

    document
        .querySelectorAll(".afore-check")
        .forEach(check => {

            check.checked = true;

        });


    ts_actualizarTextoAfores();

}


/* =========================================================
   DESELECCIONAR TODAS
   ========================================================= */

function ts_deseleccionarTodasAfores() {

    document
        .querySelectorAll(".afore-check")
        .forEach(check => {

            check.checked = false;

        });


    ts_actualizarTextoAfores();

}


/* =========================================================
   AGREGAR SERIE
   ========================================================= */

function ts_agregarSerieDatos() {

    const title =
        document.getElementById(
            "dataSeriesTitle"
        ).value.trim();


    const indent =
        parseInt(
            document.getElementById(
                "dataSeriesIndent"
            ).value
        ) || 0;


    const parentIdValue =
        document.getElementById(
            "parentSeries"
        ).value;


    const parentId =
        parentIdValue === ""
            ? null
            : Number(parentIdValue);


    const afores =
        ts_obtenerAforesSeleccionadas();


    /* =============================================
       VALIDACIONES
       ============================================= */

    if (!title) {

        ts_mostrarMensaje(
            "Debe indicar el título de la serie.",
            "warning"
        );

        return;

    }


    if (afores.length === 0) {

        ts_mostrarMensaje(
            "Debe seleccionar al menos una AFORE.",
            "warning"
        );

        return;

    }


    /* =============================================
       VALIDAR RELACIÓN PADRE
       ============================================= */

    if (parentId !== null) {

        const parent =
            ts_seriesDatos.find(
                serie =>
                    serie.id === parentId
            );


        if (!parent) {

            ts_mostrarMensaje(
                "La serie padre seleccionada no existe.",
                "warning"
            );

            return;

        }

        /*
         * La serie hija debe tener una sangría
         * mayor que la de su padre.
         */

        if (indent <= parent.indent) {

            ts_mostrarMensaje(
                "La serie hija debe tener una sangría mayor que la serie padre.",
                "warning"
            );

            return;

        }

    }


    /* =============================================
       CREAR SERIE
       ============================================= */

    const nuevaSerie = {

        id: ts_siguienteSerieId++,

        parentId,

        title,

        indent,

        afores

    };


    ts_seriesDatos.push(
        nuevaSerie
    );


    /* =============================================
       ACTUALIZAR INTERFAZ
       ============================================= */

    ts_renderizarSeriesConfiguradas();

    ts_actualizarCatalogoSeriesPadre();

    ts_actualizarVistaPreviaSeries();


    ts_limpiarFormularioSerieDatos();

    const ts_aforeMenu = document.getElementById("aforesDropdown");
    const ts_aforeButton = document.getElementById("aforesSelectorButton");
    if (ts_aforeMenu) ts_aforeMenu.classList.remove("ts-show");
    if (ts_aforeButton) {
        ts_aforeButton.classList.remove("show");
        ts_aforeButton.setAttribute("aria-expanded", "false");
    }


    ts_mostrarMensaje(
        "Serie agregada correctamente.",
        "success"
    );

}


/* =========================================================
   CATALOGO DE SERIES PADRE
   ========================================================= */

function ts_actualizarCatalogoSeriesPadre() {

    const select =
        document.getElementById(
            "parentSeries"
        );


    const selectedValue =
        select.value;


    select.innerHTML = `

        <option value="">
            Serie principal / sin padre
        </option>

    `;


    ts_seriesDatos.forEach(serie => {

        const option =
            document.createElement(
                "option"
            );


        option.value =
            serie.id;


        option.textContent =
            `${"— ".repeat(serie.indent)}${serie.title}`;


        select.appendChild(
            option
        );

    });


    if (
        ts_seriesDatos.some(
            serie =>
                String(serie.id) ===
                selectedValue
        )
    ) {

        select.value =
            selectedValue;

    }

    if (typeof ts_vinculosActualizarCatalogo === "function") ts_vinculosActualizarCatalogo();

}


/* =========================================================
   RENDERIZAR SERIES CONFIGURADAS
   ========================================================= */

function ts_renderizarSeriesConfiguradas() {

    const container =
        document.getElementById(
            "configuredSeriesContainer"
        );


    if (ts_seriesDatos.length === 0) {

        container.innerHTML = `

            <div class="empty-message">

                No existen ts_series configuradas.

            </div>

        `;

        return;

    }


    container.innerHTML = "";


    const roots =
        ts_seriesDatos.filter(
            serie =>
                serie.parentId === null
        );


    roots.forEach(root => {

        ts_renderizarNodoSerie(
            root,
            container
        );

    });

}


/* =========================================================
   RENDERIZAR NODO
   ========================================================= */

function ts_renderizarNodoSerie(
    serie,
    container
) {

    const wrapper =
        document.createElement(
            "div"
        );


    wrapper.className =
        serie.parentId !== null
            ? "ts_series-tree-line"
            : "";


    const item =
        document.createElement(
            "div"
        );


    item.className =
        "configured-ts_series-item";


    item.style.marginLeft =
        `${serie.indent * 12}px`;


    item.innerHTML = `

        <div class="d-flex justify-content-between
                    align-items-start">

            <div>

                <div class="configured-ts_series-title">

                    ${serie.parentId !== null
            ? '<span class="ts_series-parent-indicator">↳</span>'
            : ''
        }

                    ${ts_escapeHtml(serie.title)}

                </div>


                <div class="configured-ts_series-meta">

                    Nivel de sangría:
                    ${serie.indent}

                    &nbsp; · &nbsp;

                    ${serie.afores.length}
                    AFORE(s)

                </div>

            </div>


            <button
                class="btn btn-sm btn-outline-danger"
                onclick="ts_eliminarSerieDatos(${serie.id})">

                <i class="bi bi-trash"></i>

            </button>

        </div>


        <div class="configured-ts_series-meta mt-2">

            ${serie.afores
            .map(
                afore =>
                    `<span class="badge text-bg-light me-1">
                            ${ts_escapeHtml(afore)}
                        </span>`
            )
            .join("")}

        </div>

    `;


    wrapper.appendChild(item);

    container.appendChild(wrapper);


    /*
     * Buscar hijos de la serie.
     */

    const children =
        ts_seriesDatos.filter(
            child =>
                child.parentId === serie.id
        );


    children.forEach(child => {

        ts_renderizarNodoSerie(
            child,
            container
        );

    });

}


/* =========================================================
   ELIMINAR SERIE
   ========================================================= */

function ts_eliminarSerieDatos(id) {

    const serieObjetivo = ts_seriesDatos.find(serie => serie.id === id);
    if (!serieObjetivo) return;

    const hasChildren =
        ts_seriesDatos.some(
            serie =>
                serie.parentId === id
        );


    if (hasChildren) {

        ts_mostrarMensaje(
            "No se puede eliminar la serie porque tiene ts_series hijas.",
            "warning"
        );

        return;

    }


    if (!confirm(`¿Quitar la serie “${serieObjetivo.title}”?\n\nEsta acción modificará la estructura del cuadro.`)) return;

    ts_seriesDatos =
        ts_seriesDatos.filter(
            serie =>
                serie.id !== id
        );
    Object.keys(ts_valoresDatos).forEach(key => {
        if (key.startsWith(`${id}::`)) delete ts_valoresDatos[key];
    });


    ts_renderizarSeriesConfiguradas();

    ts_actualizarCatalogoSeriesPadre();

    ts_actualizarVistaPreviaSeries();

}


/* =========================================================
   LIMPIAR FORMULARIO
   ========================================================= */

function ts_limpiarFormularioSerieDatos() {

    document.getElementById(
        "dataSeriesTitle"
    ).value = "";


    document.getElementById(
        "dataSeriesIndent"
    ).value = 0;


    document.getElementById(
        "dataSeriesIndentValue"
    ).textContent = "0";


    document.getElementById(
        "parentSeries"
    ).value = "";


    ts_deseleccionarTodasAfores();

}


/* =========================================================
   ESCAPAR HTML
   ========================================================= */

function ts_escapeHtml(text) {

    const div =
        document.createElement("div");

    div.textContent = text;

    return div.innerHTML;

}

/* =========================================================
   ACTUALIZAR PREVISUALIZACIÓN DE SERIES
   ========================================================= */

function ts_actualizarVistaPreviaSeries() {

    const existing =
        document.getElementById(
            "previewSeriesData"
        );


    if (existing) {

        existing.remove();

    }


    if (ts_seriesDatos.length === 0) {

        return;

    }


    const chartContainer = null;


    const seriesContainer =
        document.createElement(
            "div"
        );


    seriesContainer.id =
        "previewSeriesData";


    seriesContainer.className =
        "preview-series-data";


    ts_datosAsegurarValores();

    seriesContainer.style.setProperty("--ts-data-cols", String(ts_periodosDatos.length));
    seriesContainer.innerHTML = `
        <div class="preview-series-header" style="grid-template-columns:minmax(230px,1.7fr) repeat(${ts_periodosDatos.length}, minmax(100px,1fr));">
            <div class="preview-concept">CONCEPTO</div>
            ${ts_periodosDatos.map(periodo => `<div>${ts_escapeHtml(periodo.label)}</div>`).join("")}
        </div>
    `;


    const roots =
        ts_seriesDatos.filter(
            serie =>
                serie.parentId === null
        );


    roots.forEach(
        root => {

            ts_renderizarSeriePreview(
                root,
                seriesContainer
            );

        }
    );


    /*
     * La tabla se coloca antes de la gráfica.
     */

    const previewNotes = document.getElementById("previewNotes");
    const previewDocument = document.getElementById("previewDocument");

    if (previewNotes) {
        previewNotes.insertAdjacentElement("beforebegin", seriesContainer);
    } else if (previewDocument) {
        previewDocument.appendChild(seriesContainer);
    }

}


/* =========================================================
   RENDERIZAR SERIE EN PREVISUALIZACIÓN
   ========================================================= */

function ts_renderizarSeriePreview(
    serie,
    container
) {

    /*
     * Título de la serie.
     */

    const titleRow =
        document.createElement(
            "div"
        );


    titleRow.className =
        "preview-series-row preview-series-title-row";
    titleRow.dataset.level = String(serie.indent);



    titleRow.style.gridTemplateColumns = `minmax(230px,1.7fr) repeat(${ts_periodosDatos.length}, minmax(100px,1fr))`;
    titleRow.innerHTML = `
        <div class="preview-concept" style="padding-left:${serie.indent * 24 + 8}px">
            <span class="preview-checkbox">□</span>
            ${ts_escapeHtml(serie.title)}
        </div>
        ${ts_periodosDatos.map(() => `<div></div>`).join("")}
    `;


    container.appendChild(
        titleRow
    );


    /*
     * AFORE pertenecientes a la serie.
     */

    serie.afores.forEach(
        (afore, index) => {

            const row =
                document.createElement(
                    "div"
                );


            row.className =
                "preview-series-row preview-afore-row";
            row.dataset.level = String(serie.indent + 1);


            /*
             * La AFORE tiene la misma sangría
             * de la serie.
             */

            row.dataset.indent = serie.indent + 1;


            const baseValue =
                ts_obtenerValorEjemplo(
                    serie.id,
                    index
                );


            row.style.gridTemplateColumns = `minmax(230px,1.7fr) repeat(${ts_periodosDatos.length}, minmax(100px,1fr))`;
            row.innerHTML = `
                <div class="preview-concept" style="padding-left:${(serie.indent + 1) * 24 + 8}px">
                    <span class="preview-checkbox">□</span>
                    ${ts_escapeHtml(afore)}
                </div>
                ${ts_periodosDatos.map(periodo => {
                    const key = ts_datosClave(serie.id, afore, periodo.id);
                    const value = ts_valoresDatos[key];
                    return `<div>${value === null || value === undefined || value === "" ? '<span class="text-muted">—</span>' : (typeof value === "number" ? ts_formatearNumero(value) : ts_escapeHtml(String(value)))}</div>`;
                }).join("")}
            `;


            container.appendChild(
                row
            );

        }
    );


    /*
     * Buscar ts_series hijas.
     */

    const children =
        ts_seriesDatos.filter(
            child =>
                child.parentId === serie.id
        );


    children.forEach(
        child => {

            ts_renderizarSeriePreview(
                child,
                container
            );

        }
    );

}


/* =========================================================
   VALORES DE EJEMPLO
   ========================================================= */

function ts_obtenerValorEjemplo(
    serieId,
    index
) {

    const valores = [

        76918549,
        68799591,
        17038522,
        8561379,
        11868514,
        1108447,
        1864292,
        2520067,
        2291840,
        8387899

    ];


    const base =
        valores[index % valores.length];


    return base *
        (1 + ((serieId - 1) * 0.025));

}


/* =========================================================
   FORMATEAR NUMERO
   ========================================================= */

function ts_formatearNumero(numero) {

    const decimals =
        ts_configuracionSerie &&
            ts_configuracionSerie.decimales !== undefined
            ? Number(
                ts_configuracionSerie.decimales
            )
            : 0;


    return Number(numero)
        .toLocaleString(
            "es-MX",
            {
                minimumFractionDigits:
                    decimals,

                maximumFractionDigits:
                    decimals
            }
        );

}

/* =========================================================
   EXPORTAR A EXCEL
   ========================================================= */

function ts_exportarExcel() {

    if (ts_seriesDatos.length === 0) {

        ts_mostrarMensaje(
            "No existen ts_series de ts_datos para exportar.",
            "warning"
        );

        return;

    }


    const filas =
        ts_construirDatosExportacion();


    const worksheet =
        XLSX.utils.json_to_sheet(
            filas
        );


    const workbook =
        XLSX.utils.book_new();


    XLSX.utils.book_append_sheet(
        workbook,
        worksheet,
        "Series de ts_datos"
    );


    const titulo =
        ts_obtenerTituloExportacion();


    const nombreArchivo =
        ts_sanitizarNombreArchivo(
            titulo
        );


    XLSX.writeFile(
        workbook,
        `${nombreArchivo}.xlsx`
    );


    ts_mostrarMensaje(
        "El archivo Excel fue generado correctamente.",
        "success"
    );

}

/* =========================================================
   CONSTRUIR DATOS DE EXPORTACIÓN
   ========================================================= */

function ts_construirDatosExportacion() {

    const filas = [];


    ts_seriesDatos.forEach(
        serie => {

            /*
             * La serie se exporta como un registro.
             */

            serie.afores.forEach(
                afore => {

                    filas.push({

                        "Serie":
                            ts_obtenerRutaSerie(
                                serie.id
                            ),

                        "AFORE":
                            afore,

                        "Sangría":
                            serie.indent,

                        "Junio 2025":
                            ts_obtenerValorEjemplo(
                                serie.id,
                                0
                            ),

                        "Mayo 2026":
                            ts_obtenerValorEjemplo(
                                serie.id,
                                0
                            ) * 1.035,

                        "Junio 2026":
                            ts_obtenerValorEjemplo(
                                serie.id,
                                0
                            ) * 1.041

                    });

                }

            );

        }
    );


    return filas;
}

/* =========================================================
   OBTENER RUTA DE LA SERIE
   ========================================================= */

function ts_obtenerRutaSerie(id) {

    const serie =
        ts_seriesDatos.find(
            item => item.id === id
        );


    if (!serie) {

        return "";

    }


    if (serie.parentId === null) {

        return serie.title;

    }


    return (
        ts_obtenerRutaSerie(
            serie.parentId
        )
        +
        " > "
        +
        serie.title
    );

}

/* =========================================================
   EXPORTAR CSV
   ========================================================= */

function ts_exportarCSV() {

    if (ts_seriesDatos.length === 0) {

        ts_mostrarMensaje(
            "No existen ts_series de ts_datos para exportar.",
            "warning"
        );

        return;

    }


    const filas =
        ts_construirDatosExportacion();


    if (filas.length === 0) {

        return;

    }


    const headers =
        Object.keys(
            filas[0]
        );


    const csv = [

        headers.join(","),

        ...filas.map(
            fila =>
                headers
                    .map(
                        header =>
                            ts_escaparCSV(
                                fila[header]
                            )
                    )
                    .join(",")
        )

    ].join("\n");


    const blob =
        new Blob(
            [
                "\uFEFF" + csv
            ],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );


    ts_descargarArchivo(
        blob,
        `${ts_sanitizarNombreArchivo(
            ts_obtenerTituloExportacion()
        )}.csv`
    );


    ts_mostrarMensaje(
        "El archivo CSV fue generado correctamente.",
        "success"
    );

}

function ts_escaparCSV(valor) {

    if (
        valor === null ||
        valor === undefined
    ) {

        return "";

    }


    const texto =
        String(valor);


    if (
        texto.includes(",") ||
        texto.includes('"') ||
        texto.includes("\n")
    ) {

        return `"${texto.replace(
            /"/g,
            '""'
        )}"`;

    }


    return texto;

}

/* =========================================================
   EXPORTAR PDF
   ========================================================= */

function ts_exportarPDF() {

    if (ts_seriesDatos.length === 0) {

        ts_mostrarMensaje(
            "No existen ts_series de ts_datos para exportar.",
            "warning"
        );

        return;

    }


    const {
        jsPDF
    } = window.jspdf;


    const doc =
        new jsPDF({
            orientation: "landscape",
            unit: "mm",
            format: "letter"
        });


    const titulo =
        ts_obtenerTituloExportacion();


    /*
     * Título
     */

    doc.setFontSize(15);

    doc.setFont(
        "helvetica",
        "bold"
    );


    doc.text(
        titulo,
        15,
        15
    );


    /*
     * Información general
     */

    doc.setFontSize(8);

    doc.setFont(
        "helvetica",
        "normal"
    );


    let y = 23;


    if (
        ts_configuracionSerie.descripcion
    ) {

        doc.text(
            ts_configuracionSerie.descripcion,
            15,
            y,
            {
                maxWidth: 250
            }
        );

        y += 7;

    }


    doc.text(
        `Periodicidad: ${ts_configuracionSerie.periodicidad || "—"
        }`,
        15,
        y
    );


    doc.text(
        `Unidad: ${ts_configuracionSerie.unidad || "—"
        }`,
        100,
        y
    );


    doc.text(
        180,
        y
    );


    y += 8;


    /*
     * Tabla
     */

    const filas =
        ts_construirDatosExportacion();


    const body =
        filas.map(
            fila => [

                fila["Serie"],

                fila["AFORE"],

                fila["Junio 2025"],

                fila["Mayo 2026"],

                fila["Junio 2026"]

            ]
        );


    doc.autoTable({

        startY: y,

        head: [[

            "Serie",

            "AFORE",

            "Junio 2025",

            "Mayo 2026",

            "Junio 2026"

        ]],

        body,

        styles: {

            fontSize: 7,

            cellPadding: 2

        },

        headStyles: {

            fontStyle: "bold"

        },

        columnStyles: {

            0: {
                cellWidth: 85
            },

            1: {
                cellWidth: 45
            },

            2: {
                halign: "right"
            },

            3: {
                halign: "right"
            },

            4: {
                halign: "right"
            }

        }

    });


    const nombreArchivo =
        ts_sanitizarNombreArchivo(
            titulo
        );


    doc.save(
        `${nombreArchivo}.pdf`
    );


    ts_mostrarMensaje(
        "El archivo PDF fue generado correctamente.",
        "success"
    );

}

/* =========================================================
   EXPORTAR IQY
   ========================================================= */

function ts_exportarIQY() {

    const titulo =
        ts_obtenerTituloExportacion();


    /*
     * URL del servicio que posteriormente
     * proporcionará los ts_datos.
     *
     * En producción esta URL deberá sustituirse
     * por el API real del sistema.
     */

    const url =
        "https://ejemplo.consar.gob.mx/api/ts_series";


    const iqy =

        `WEB
1
${url}

Selection=Entire Page
Formatting=None
PreFormattedTextToColumns=True
ConsecutiveDelimitersAsOne=True
SingleBlockTextImport=False
DisableDateRecognition=False
DisableRedirections=False`;


    const blob =
        new Blob(
            [iqy],
            {
                type:
                    "application/x-iqy"
            }
        );


    ts_descargarArchivo(
        blob,
        `${ts_sanitizarNombreArchivo(
            titulo
        )}.iqy`
    );


    ts_mostrarMensaje(
        "El archivo IQY fue generado correctamente.",
        "success"
    );

}

/* =========================================================
   DESCARGAR ARCHIVO
   ========================================================= */

function ts_descargarArchivo(
    blob,
    nombre
) {

    const url =
        URL.createObjectURL(
            blob
        );


    const enlace =
        document.createElement(
            "a"
        );


    enlace.href = url;

    enlace.download = nombre;


    document.body.appendChild(
        enlace
    );


    enlace.click();


    document.body.removeChild(
        enlace
    );


    URL.revokeObjectURL(
        url
    );

}


/* =========================================================
   OBTENER TITULO
   ========================================================= */

function ts_obtenerTituloExportacion() {

    const titulo =
        document.getElementById(
            "previewTitle"
        );


    if (
        titulo &&
        titulo.textContent.trim()
    ) {

        return titulo.textContent.trim();

    }


    return "serie_tiempo";

}


/* =========================================================
   SANITIZAR NOMBRE
   ========================================================= */

function ts_sanitizarNombreArchivo(
    nombre
) {

    return nombre

        .normalize("NFD")

        .replace(
            /[\u0300-\u036f]/g,
            ""
        )

        .replace(
            /[^a-zA-Z0-9_-]+/g,
            "_"
        )

        .replace(
            /^_+|_+$/g,
            ""
        )

        .substring(
            0,
            80
        )

        || "serie_tiempo";

}




/* =========================================================
   CRUD DE CREACIÓN DE CUADROS Y SERIES
   Persistencia local, sin alterar las demás vistas de la SPA.
   ========================================================= */

const TS_CRUD_STORAGE_KEY = "crudCuadrosSeriesV3";
let ts_crudIdActual = null;

function ts_crudClonar(valor) {
    return JSON.parse(JSON.stringify(valor ?? null));
}

function ts_crudLeerRegistros() {
    try {
        const raw = localStorage.getItem(TS_CRUD_STORAGE_KEY);
        const data = raw ? JSON.parse(raw) : [];
        return Array.isArray(data) ? data : [];
    } catch (error) {
        console.error("No fue posible leer los cuadros guardados", error);
        return [];
    }
}

function ts_crudPersistirRegistros(registros) {
    localStorage.setItem(TS_CRUD_STORAGE_KEY, JSON.stringify(registros));
    ts_crudActualizarContador();
}

function ts_crudGenerarId() {
    const registros = ts_crudLeerRegistros();
    const numeros = registros
        .map(r => String(r.id || "").match(/(\d+)$/))
        .filter(Boolean)
        .map(m => Number(m[1]));
    const siguiente = (numeros.length ? Math.max(...numeros) : 0) + 1;
    return `CS-${String(siguiente).padStart(4, "0")}`;
}

function ts_crudRecolectarFormulario() {
    // Sincronizar lo que el usuario ve con el estado antes de guardar.
    ts_actualizarTitulo();
    ts_agregarConfiguracionSerieSilenciosa();
    ts_actualizarNotas();
    ts_actualizarVistaPreviaSeries();

    const ahora = new Date().toISOString();
    const registros = ts_crudLeerRegistros();
    const existente = registros.find(r => r.id === ts_crudIdActual);

    return {
        id: ts_crudIdActual || ts_crudGenerarId(),
        creadoEn: existente?.creadoEn || ahora,
        actualizadoEn: ahora,
        titulo: {
            texto: document.getElementById("chartTitle")?.value.trim() || "",
            renglon: document.getElementById("titleRow")?.value || "1",
            alineacion: document.getElementById("titleAlignment")?.value || "center",
            sangria: document.getElementById("titleIndent")?.value || "0"
        },
        configuracionSerie: ts_crudClonar(ts_configuracionSerie) || {},
        seriesDatos: ts_crudClonar(ts_seriesDatos) || [],
        vinculosSeriesCuadros: ts_crudIdActual ? (ts_crudClonar(ts_vinculosSeriesCuadros) || {}) : {},
        periodosDatos: ts_crudClonar(ts_periodosDatos) || [],
        valoresDatos: ts_crudClonar(ts_valoresDatos) || {},
        siguienteSerieId: ts_siguienteSerieId,
        notas: document.getElementById("chartNotes")?.value || "",
        fuente: document.getElementById("chartSource")?.value || "",
        // Se conservan estos arreglos por compatibilidad con configuraciones anteriores.
        seriesLegacy: ts_crudClonar(ts_series) || [],
        datosLegacy: ts_crudClonar(ts_datos) || []
    };
}

function ts_agregarConfiguracionSerieSilenciosa() {
    ts_configuracionSerie = {
        descripcion: document.getElementById("seriesDescription")?.value.trim() || "",
        decimales: document.getElementById("decimalPlaces")?.value ?? "2",
        tipoCifra: document.getElementById("figureType")?.value || "",
        periodicidad: document.getElementById("seriesFrequency")?.value || "",
        periodoInicio: document.getElementById("availablePeriodStart")?.value || "",
        periodoFin: document.getElementById("availablePeriodEnd")?.value || "",
        unidad: document.getElementById("seriesUnit")?.value || ""
    };
    ts_actualizarInformacionSerie();
}

function ts_crudValidar(registro) {
    if (!registro.titulo.texto) {
        ts_mostrarMensaje("Capture el título del cuadro antes de guardarlo.", "warning");
        document.getElementById("chartTitle")?.focus();
        return false;
    }
    if (!registro.configuracionSerie.descripcion) {
        ts_mostrarMensaje("Capture la descripción del cuadro.", "warning");
        document.getElementById("seriesDescription")?.focus();
        return false;
    }
    if (!registro.seriesDatos.length) {
        ts_mostrarMensaje("Agregue al menos una serie de datos a la estructura jerárquica.", "warning");
        return false;
    }
    return true;
}

let ts_crudOrigenActualizacionPagina = false;

function ts_crudGuardar() {
    const registro = ts_crudRecolectarFormulario();
    if (!ts_crudValidar(registro)) return;

    const registros = ts_crudLeerRegistros();
    const index = registros.findIndex(r => r.id === registro.id);
    const esEdicion = index >= 0;

    if (esEdicion) registros[index] = registro;
    else registros.push(registro);

    ts_crudPersistirRegistros(registros);
    ts_crudIdActual = registro.id;
    ts_crudActualizarEstado();
    ts_mostrarMensaje(
        esEdicion ? `Cuadro ${registro.id} actualizado correctamente.` : `Cuadro ${registro.id} creado correctamente.`,
        "success"
    );

    if (esEdicion && ts_crudOrigenActualizacionPagina) {
        ts_crudOrigenActualizacionPagina = false;
        const nuevo = document.getElementById("tsNuevoBtn");
        if (nuevo) nuevo.classList.remove("d-none");

        if (typeof showView === "function") showView("tables-update");
        document.querySelectorAll(".sidebar-nav .nav-link").forEach(link => link.classList.remove("active"));
        document.querySelector('[data-view="tables-update"]')?.classList.add("active");
        ts_crudPrepararPaginaActualizacion();
    }
}

function ts_crudNuevo() {
    ts_crudOrigenActualizacionPagina = false;
    const nuevoBtn = document.getElementById("tsNuevoBtn");
    if (nuevoBtn) nuevoBtn.classList.remove("d-none");
    ts_crudIdActual = null;
    ts_series = [];
    ts_datos = [];
    ts_seriesDatos = [];
    ts_vinculosSeriesCuadros = {};
    ts_periodosDatos = [
        { id: "p1", label: "JUNIO 2025" },
        { id: "p2", label: "MAYO 2026" },
        { id: "p3", label: "JUNIO 2026" }
    ];
    ts_valoresDatos = {};
    ts_editorDatosCerrar();
    ts_siguienteSerieId = 1;
    ts_configuracionSerie = {
        descripcion: "", decimales: 2, tipoCifra: "", periodicidad: "",
        periodoInicio: "", periodoFin: "", unidad: ""
    };

    const valores = {
        chartTitle: "", titleRow: "1", titleAlignment: "center", titleIndent: "0",
        seriesDescription: "", decimalPlaces: "2", figureType: "", seriesFrequency: "",
        availablePeriodStart: "", availablePeriodEnd: "", seriesUnit: "",
        chartNotes: "", chartSource: "", dataSeriesTitle: "", dataSeriesIndent: "0", parentSeries: ""
    };
    Object.entries(valores).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });

    document.querySelectorAll("#tables .afore-check").forEach(c => c.checked = false);
    const indent = document.getElementById("indentValue");
    if (indent) indent.textContent = "0";
    const dataIndent = document.getElementById("dataSeriesIndentValue");
    if (dataIndent) dataIndent.textContent = "0";

    document.getElementById("seriesInformation")?.remove();
    document.getElementById("previewSeriesData")?.remove();
    ts_actualizarTextoAfores();
    ts_renderizarSeriesConfiguradas();
    ts_actualizarCatalogoSeriesPadre();
    ts_actualizarTitulo();
    ts_actualizarNotas();
    ts_crudActualizarEstado();
    ts_mostrarMensaje("Formulario preparado para crear un nuevo cuadro.", "info");
}

function ts_crudAplicarRegistro(registro) {
    if (!registro) return;
    ts_crudIdActual = registro.id;

    const t = registro.titulo || {};
    const c = registro.configuracionSerie || {};
    const valores = {
        chartTitle: t.texto || "",
        titleRow: t.renglon || "1",
        titleAlignment: t.alineacion || "center",
        titleIndent: t.sangria ?? "0",
        seriesDescription: c.descripcion || "",
        decimalPlaces: c.decimales ?? "2",
        figureType: c.tipoCifra || "",
        seriesFrequency: c.periodicidad || "",
        availablePeriodStart: c.periodoInicio || "",
        availablePeriodEnd: c.periodoFin || "",
        seriesUnit: c.unidad || "",
        chartNotes: registro.notas || "",
        chartSource: registro.fuente || ""
    };
    Object.entries(valores).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });

    ts_configuracionSerie = ts_crudClonar(c) || {};
    ts_seriesDatos = ts_crudClonar(registro.seriesDatos) || [];
    ts_vinculosSeriesCuadros = ts_crudClonar(registro.vinculosSeriesCuadros) || {};
    ts_periodosDatos = ts_crudClonar(registro.periodosDatos) || [
        { id: "p1", label: "JUNIO 2025" },
        { id: "p2", label: "MAYO 2026" },
        { id: "p3", label: "JUNIO 2026" }
    ];
    ts_valoresDatos = ts_crudClonar(registro.valoresDatos) || {};
    ts_datosAsegurarValores();
    ts_editorDatosCerrar();
    ts_siguienteSerieId = Number(registro.siguienteSerieId) ||
        (ts_seriesDatos.reduce((max, s) => Math.max(max, Number(s.id) || 0), 0) + 1);
    ts_series = ts_crudClonar(registro.seriesLegacy) || [];
    ts_datos = ts_crudClonar(registro.datosLegacy) || [];

    const indent = document.getElementById("indentValue");
    if (indent) indent.textContent = String(t.sangria ?? 0);
    ts_deseleccionarTodasAfores();
    ts_renderizarSeriesConfiguradas();
    ts_actualizarCatalogoSeriesPadre();
    ts_actualizarTitulo();
    ts_actualizarInformacionSerie();
    ts_actualizarVistaPreviaSeries();
    ts_actualizarNotas();
    ts_crudActualizarEstado();
}

function ts_crudEditar(id) {
    const registro = ts_crudLeerRegistros().find(r => r.id === id);
    if (!registro) {
        ts_mostrarMensaje("El registro solicitado ya no existe.", "warning");
        return;
    }
    const listado = document.getElementById("tsCrudRegistrosModal");
    if (listado) bootstrap.Modal.getInstance(listado)?.hide();
    const detalle = document.getElementById("tsCrudDetalleModal");
    if (detalle) bootstrap.Modal.getInstance(detalle)?.hide();
    ts_crudAplicarRegistro(registro);
    ts_mostrarMensaje(`Editando ${id}. Los cambios se guardarán sobre el mismo registro.`, "info");
}

function ts_crudEliminar(id) {
    const registros = ts_crudLeerRegistros();
    const registro = registros.find(r => r.id === id);
    if (!registro) return;
    const titulo = registro.titulo?.texto || id;
    if (!confirm(`¿Desea eliminar el cuadro “${titulo}”?\n\nEsta acción no se puede deshacer.`)) return;

    ts_crudPersistirRegistros(registros.filter(r => r.id !== id));
    if (ts_crudIdActual === id) ts_crudNuevo();
    ts_crudRenderizarRegistros();
    ts_crudRenderizarPaginaActualizacion();
    ts_mostrarMensaje(`Cuadro ${id} eliminado.`, "success");
}

let ts_crudRegistroSeleccionado = null;

function ts_crudAbrirRegistros() {
    ts_crudRegistroSeleccionado = null;
    const actualizar = document.getElementById("tsCrudActualizarSeleccionadoBtn");
    if (actualizar) actualizar.disabled = true;
    ts_crudRenderizarRegistros();
    const modal = document.getElementById("tsCrudRegistrosModal");
    if (modal) bootstrap.Modal.getOrCreateInstance(modal).show();
}

function ts_crudRenderizarRegistros() {
    const body = document.getElementById("tsCrudRegistrosBody");
    const empty = document.getElementById("tsCrudSinRegistros");
    if (!body || !empty) return;

    const query = (document.getElementById("tsCrudBuscar")?.value || "").trim().toLowerCase();
    const registros = ts_crudLeerRegistros()
        .filter(r => {
            const c = r.configuracionSerie || {};
            return [r.id, r.titulo?.texto, c.periodicidad]
                .some(v => String(v || "").toLowerCase().includes(query));
        })
        .sort((a,b) => String(b.actualizadoEn || "").localeCompare(String(a.actualizadoEn || "")));

    body.innerHTML = "";
    empty.classList.toggle("d-none", registros.length !== 0);

    registros.forEach(registro => {
        const c = registro.configuracionSerie || {};
        const deshabilitado = registro.habilitado === false;
        const seleccionado = ts_crudRegistroSeleccionado === registro.id;
        const tr = document.createElement("tr");

        tr.classList.add("ts-crud-selectable-row");
        tr.dataset.registroId = registro.id;
        tr.tabIndex = 0;
        tr.setAttribute("role", "button");
        tr.setAttribute("aria-selected", seleccionado ? "true" : "false");

        if (deshabilitado) tr.classList.add("ts-crud-row-disabled");
        if (seleccionado) tr.classList.add("ts-crud-row-selected");

        tr.addEventListener("click", (event) => {
            if (event.target.closest("button, a, input, select, textarea")) return;
            ts_crudSeleccionarRegistro(registro.id);
        });

        tr.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                ts_crudSeleccionarRegistro(registro.id);
            }
        });

        tr.innerHTML = `
            <td><span class="badge text-bg-light border">${ts_escapeHtml(registro.id)}</span></td>
            <td>
              <div class="fw-semibold">${ts_escapeHtml(registro.titulo?.texto || "Sin título")}</div>
              ${deshabilitado ? '<small class="badge text-bg-secondary mt-1">Deshabilitado</small>' : ''}
            </td>
            <td>${ts_escapeHtml(c.periodicidad || "—")}</td>
            <td class="text-center">
              <span class="badge rounded-pill ${ts_vinculosContarRegistro(registro) ? 'text-bg-primary' : 'text-bg-light border text-secondary'}">
                <i class="bi bi-link-45deg me-1"></i>${ts_vinculosContarRegistro(registro)}
              </span>
            </td>
            <td class="text-nowrap"><small>${ts_crudFecha(registro.actualizadoEn)}</small></td>
            <td class="text-end text-nowrap">
              <button class="btn btn-sm ${deshabilitado ? 'btn-outline-success' : 'btn-outline-danger'}" 
                      title="${deshabilitado ? 'Habilitar' : 'Deshabilitar'}"
                      onclick="event.stopPropagation(); ts_crudCambiarEstado('${registro.id}')">
                <i class="bi ${deshabilitado ? 'bi-check-circle' : 'bi-slash-circle'} me-1"></i>
                ${deshabilitado ? 'Habilitar' : 'Deshabilitar'}
              </button>
            </td>`;
        body.appendChild(tr);
    });
}


function ts_crudSeleccionarRegistro(id) {
    ts_crudRegistroSeleccionado = id;

    document.querySelectorAll("#tsCrudRegistrosBody .ts-crud-selectable-row, #tsCrudRegistrosPaginaBody .ts-crud-selectable-row").forEach(row => {
        const seleccionado = row.dataset.registroId === id;
        row.classList.toggle("ts-crud-row-selected", seleccionado);
        row.setAttribute("aria-selected", seleccionado ? "true" : "false");
    });

    const modalBtn = document.getElementById("tsCrudActualizarSeleccionadoBtn");
    const pageBtn = document.getElementById("tsCrudActualizarPaginaBtn");
    if (modalBtn) modalBtn.disabled = !id;
    if (pageBtn) pageBtn.disabled = !id;
}

function ts_crudActualizarSeleccionado() {
    if (!ts_crudRegistroSeleccionado) {
        ts_mostrarMensaje("Seleccione un cuadro antes de actualizarlo.", "warning");
        return;
    }

    const registro = ts_crudLeerRegistros().find(r => r.id === ts_crudRegistroSeleccionado);
    if (!registro) {
        ts_mostrarMensaje("El registro seleccionado ya no existe.", "warning");
        return;
    }

    // Asegurar que se muestre el constructor y no la pantalla de Consulta SQL.
    if (typeof ts_mostrarModoCuadros === "function") ts_mostrarModoCuadros(false);

    ts_crudAplicarRegistro(registro);

    const modal = document.getElementById("tsCrudRegistrosModal");
    if (modal) bootstrap.Modal.getOrCreateInstance(modal).hide();

    // Mantener el acordeón colapsado, pero con todos los campos ya cargados.
    document.querySelectorAll("#configurationAccordion .accordion-collapse.show").forEach(element => {
        bootstrap.Collapse.getOrCreateInstance(element, { toggle: false }).hide();
    });

    ts_mostrarMensaje(`Cuadro ${registro.id} cargado para actualización.`, "info");
}


function ts_crudPrepararPaginaActualizacion() {
    ts_crudRegistroSeleccionado = null;
    const btn = document.getElementById("tsCrudActualizarPaginaBtn");
    if (btn) btn.disabled = true;
    const buscar = document.getElementById("tsCrudBuscarPagina");
    if (buscar) buscar.value = "";
    ts_crudRenderizarPaginaActualizacion();
}

function ts_crudRenderizarPaginaActualizacion() {
    const body = document.getElementById("tsCrudRegistrosPaginaBody");
    const empty = document.getElementById("tsCrudSinRegistrosPagina");
    if (!body || !empty) return;

    const query = (document.getElementById("tsCrudBuscarPagina")?.value || "").trim().toLowerCase();
    const registros = ts_crudLeerRegistros()
        .filter(r => {
            const c = r.configuracionSerie || {};
            return [r.id, r.titulo?.texto, c.periodicidad]
                .some(v => String(v || "").toLowerCase().includes(query));
        })
        .sort((a,b) => String(b.actualizadoEn || "").localeCompare(String(a.actualizadoEn || "")));

    body.innerHTML = "";
    empty.classList.toggle("d-none", registros.length !== 0);

    registros.forEach(registro => {
        const c = registro.configuracionSerie || {};
        const deshabilitado = registro.habilitado === false;
        const seleccionado = ts_crudRegistroSeleccionado === registro.id;
        const tr = document.createElement("tr");
        tr.classList.add("ts-crud-selectable-row");
        tr.dataset.registroId = registro.id;
        tr.tabIndex = 0;
        tr.setAttribute("role", "button");
        tr.setAttribute("aria-selected", seleccionado ? "true" : "false");
        if (deshabilitado) tr.classList.add("ts-crud-row-disabled");
        if (seleccionado) tr.classList.add("ts-crud-row-selected");

        tr.addEventListener("click", event => {
            if (event.target.closest("button, a, input, select, textarea")) return;
            ts_crudSeleccionarRegistro(registro.id);
        });
        tr.addEventListener("keydown", event => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                ts_crudSeleccionarRegistro(registro.id);
            }
        });

        tr.innerHTML = `
            <td><span class="badge text-bg-light border">${ts_escapeHtml(registro.id)}</span></td>
            <td>
              <div class="fw-semibold">${ts_escapeHtml(registro.titulo?.texto || "Sin título")}</div>
              ${deshabilitado ? '<small class="badge text-bg-secondary mt-1">Deshabilitado</small>' : ''}
            </td>
            <td>${ts_escapeHtml(c.periodicidad || "—")}</td>
            <td class="text-nowrap"><small>${ts_crudFecha(registro.actualizadoEn)}</small></td>
            <td class="text-end text-nowrap">
              <button class="btn btn-sm ${deshabilitado ? 'btn-outline-success' : 'btn-outline-danger'}"
                      title="${deshabilitado ? 'Habilitar' : 'Deshabilitar'}"
                      onclick="event.stopPropagation(); ts_crudCambiarEstado('${registro.id}')">
                <i class="bi ${deshabilitado ? 'bi-check-circle' : 'bi-slash-circle'} me-1"></i>
                ${deshabilitado ? 'Habilitar' : 'Deshabilitar'}
              </button>
            </td>`;
        body.appendChild(tr);
    });
}

function ts_crudActualizarDesdePagina() {
    if (!ts_crudRegistroSeleccionado) {
        ts_mostrarMensaje("Seleccione un cuadro para actualizar.", "warning");
        return;
    }
    const registro = ts_crudLeerRegistros().find(r => r.id === ts_crudRegistroSeleccionado);
    if (!registro) {
        ts_mostrarMensaje("El registro seleccionado ya no existe.", "warning");
        ts_crudPrepararPaginaActualizacion();
        return;
    }
    ts_crudOrigenActualizacionPagina = true;
    if (typeof showView === "function") showView("tables");
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector('[data-view="tables-update"]')?.classList.add('active');

    const nuevoBtn = document.getElementById("tsNuevoBtn");
    if (nuevoBtn) nuevoBtn.classList.add("d-none");

    ts_crudAplicarRegistro(registro);
    ts_mostrarMensaje(`Editando ${registro.id}. Al oprimir Actualizar regresará al listado de cuadros y series.`, "info");
}

function ts_crudCambiarEstado(id) {
    const registros = ts_crudLeerRegistros();
    const registro = registros.find(r => r.id === id);
    if (!registro) {
        ts_mostrarMensaje("El registro solicitado ya no existe.", "warning");
        return;
    }

    registro.habilitado = registro.habilitado === false;
    registro.actualizadoEn = new Date().toISOString();
    ts_crudPersistirRegistros(registros);

    // Refrescar tanto el modal como la vista de Cuadros y Series > Actualizar.
    // Antes solo se redibujaba el modal y por eso el botón de la página
    // permanecía visualmente como “Deshabilitar”.
    ts_crudRenderizarRegistros();
    ts_crudRenderizarPaginaActualizacion();

    ts_mostrarMensaje(
        registro.habilitado === false
            ? `Cuadro ${id} deshabilitado correctamente.`
            : `Cuadro ${id} habilitado correctamente.`,
        "success"
    );
}

function ts_crudConsultar(id) {
    const registro = ts_crudLeerRegistros().find(r => r.id === id);
    if (!registro) return;
    const container = document.getElementById("tsCrudDetalleContenido");
    if (!container) return;
    container.innerHTML = ts_crudConstruirDetalle(registro);
    const editar = document.getElementById("tsCrudDetalleEditar");
    if (editar) editar.onclick = () => ts_crudEditar(id);
    const listado = document.getElementById("tsCrudRegistrosModal");
    if (listado) bootstrap.Modal.getInstance(listado)?.hide();
    bootstrap.Modal.getOrCreateInstance(document.getElementById("tsCrudDetalleModal")).show();
}

function ts_crudConstruirDetalle(registro) {
    const c = registro.configuracionSerie || {};
    const inicio = ts_formatearPeriodo(c.periodoInicio);
    const fin = ts_formatearPeriodo(c.periodoFin);
    const periodo = inicio === "—" && fin === "—" ? "—" : `${inicio} – ${fin}`;
    return `
      <article class="ts-crud-detail preview-document">
        <div class="d-flex justify-content-between gap-3 align-items-start mb-3">
          <div>
            <div class="preview-title text-start p-0 m-0">${ts_escapeHtml(registro.titulo?.texto || "Sin título")}</div>
            <div class="text-muted small mt-1">Clave: ${ts_escapeHtml(registro.id)}</div>
          </div>
          <span class="badge text-bg-light border">Actualizado ${ts_crudFecha(registro.actualizadoEn)}</span>
        </div>
        <section class="series-information mb-4">
          <div class="series-information-title"><i class="bi bi-info-circle"></i><span>Información del cuadro / serie</span></div>
          <div class="series-information-grid">
            <div class="series-information-item series-information-description"><div class="series-information-label">Descripción</div><div class="series-information-value">${ts_escapeHtml(c.descripcion || "—")}</div></div>
            <div class="series-information-item"><div class="series-information-label">Número de decimales</div><div class="series-information-value">${ts_escapeHtml(String(c.decimales ?? "—"))}</div></div>
            <div class="series-information-item"><div class="series-information-label">Tipo de cifra</div><div class="series-information-value">${ts_escapeHtml(c.tipoCifra || "—")}</div></div>
            <div class="series-information-item"><div class="series-information-label">Periodicidad</div><div class="series-information-value">${ts_escapeHtml(c.periodicidad || "—")}</div></div>
            <div class="series-information-item"><div class="series-information-label">Periodo requerido</div><div class="series-information-value">${ts_escapeHtml(periodo)}</div></div>
            <div class="series-information-item"><div class="series-information-label">Unidad de medida</div><div class="series-information-value">${ts_escapeHtml(c.unidad || "—")}</div></div>
          </div>
        </section>
        ${ts_crudConstruirJerarquiaHTML(registro.seriesDatos || [])}
        <div class="preview-notes mt-4"><div class="notes-title">Notas</div><p>${ts_escapeHtml(registro.notas || "—")}</p></div>
        <div class="preview-footer">Fuente: ${ts_escapeHtml(registro.fuente || "—")}</div>
      </article>`;
}

function ts_crudConstruirJerarquiaHTML(series) {
    if (!series.length) return '<div class="alert alert-light border">No existen series de datos configuradas.</div>';
    const out = [];
    out.push('<div class="preview-series-data ts-crud-hierarchy">');
    out.push('<div class="preview-series-header"><div class="preview-concept">CONCEPTO</div><div>JUNIO 2025</div><div>MAYO 2026</div><div>JUNIO 2026</div></div>');
    const roots = series.filter(s => s.parentId === null || s.parentId === undefined || s.parentId === "");
    const render = serie => {
        const indent = Number(serie.indent) || 0;
        out.push(`<div class="preview-series-row preview-series-title-row"><div class="preview-concept" style="padding-left:${indent*24+8}px"><span class="preview-checkbox">□</span>${ts_escapeHtml(serie.title || "Serie")}</div><div></div><div></div><div></div></div>`);
        (serie.afores || []).forEach((afore,index) => {
            const base = ts_obtenerValorEjemplo(serie.id,index);
            out.push(`<div class="preview-series-row preview-afore-row"><div class="preview-concept" style="padding-left:${(indent+1)*24+8}px"><span class="preview-checkbox">□</span>${ts_escapeHtml(afore)}</div><div>${ts_formatearNumero(base)}</div><div>${ts_formatearNumero(base*1.035)}</div><div>${ts_formatearNumero(base*1.041)}</div></div>`);
        });
        series.filter(s => String(s.parentId) === String(serie.id)).forEach(render);
    };
    roots.forEach(render);
    out.push('</div>');
    return out.join('');
}

function ts_crudFecha(valor) {
    if (!valor) return "—";
    const fecha = new Date(valor);
    if (Number.isNaN(fecha.getTime())) return "—";
    return fecha.toLocaleString("es-MX", { dateStyle: "short", timeStyle: "short" });
}

function ts_crudActualizarContador() {
    const el = document.getElementById("tsCrudContador");
    if (el) el.textContent = String(ts_crudLeerRegistros().length);
}

function ts_crudActualizarEstado() {
    const estado = document.getElementById("tsCrudEstado");
    const panel = document.getElementById("tsCrudModoPanel");
    const boton = document.getElementById("tsCrudGuardarBtn");
    const edicion = Boolean(ts_crudIdActual);
    if (estado) {
        estado.textContent = edicion ? `Editando ${ts_crudIdActual}` : "Nuevo registro";
        estado.className = edicion ? "badge rounded-pill text-bg-warning" : "badge rounded-pill text-bg-light border";
    }
    if (panel) panel.innerHTML = edicion
        ? '<i class="bi bi-circle-fill"></i> Edición'
        : '<i class="bi bi-circle-fill"></i> Nuevo';
    if (boton) boton.innerHTML = edicion
        ? '<i class="bi bi-save me-1"></i> Actualizar'
        : '<i class="bi bi-save me-1"></i> Guardar';

    // En Crear, las nuevas series pertenecen al nuevo cuadro que el sistema asigna
    // automáticamente. La vinculación con cuadros existentes sólo aplica al editar.
    const vinculosAccordion = document.getElementById("tsVinculosAccordion");
    if (vinculosAccordion) vinculosAccordion.classList.toggle("d-none", !edicion);

    const autoInfo = document.getElementById("tsAutoCuadroInfo");
    const autoClave = document.getElementById("tsAutoCuadroClave");
    if (autoInfo) autoInfo.classList.toggle("d-none", edicion);
    if (autoClave && !edicion) autoClave.textContent = ts_crudGenerarId();

    ts_crudActualizarContador();
}

function ts_crudMigrarConfiguracionAnterior() {
    if (localStorage.getItem("tsCrudMigracionV3") === "1") return;
    const registros = ts_crudLeerRegistros();
    if (registros.length === 0) {
        try {
            const raw = localStorage.getItem("configuracionSeriesTiempo");
            if (raw) {
                const antigua = JSON.parse(raw);
                if (antigua && antigua.titulo) {
                    registros.push({
                        id: ts_crudGenerarId(),
                        creadoEn: new Date().toISOString(),
                        actualizadoEn: new Date().toISOString(),
                        titulo: { texto: antigua.titulo || "Configuración anterior", renglon: antigua["renglón"] || "1", alineacion: antigua.alineacion || "center", sangria: antigua.sangria || "0" },
                        configuracionSerie: { descripcion: "Configuración migrada desde una versión anterior", decimales: 2, tipoCifra: "", periodicidad: "", periodoInicio: "", periodoFin: "", unidad: "" },
                        seriesDatos: [], siguienteSerieId: 1,
                        notas: antigua.notas || "", fuente: antigua.fuente || "",
                        seriesLegacy: antigua.ts_series || [], datosLegacy: antigua.ts_datos || []
                    });
                    ts_crudPersistirRegistros(registros);
                }
            }
        } catch (error) {
            console.warn("No se pudo migrar la configuración anterior", error);
        }
    }
    localStorage.setItem("tsCrudMigracionV3", "1");
}

document.addEventListener("DOMContentLoaded", () => {
    ts_crudMigrarConfiguracionAnterior();
    ts_crudCrearRegistrosEjemplo();
    ts_crudActualizarEstado();
});

/* =========================================================
   MODO NUEVA CONSULTA SQL
   ========================================================= */
let ts_sqlConexionActiva = false;

function ts_mostrarModoCuadros(crearNuevo = false) {
    const cuadros = document.getElementById('tsModoCuadros');
    const consulta = document.getElementById('tsModoConsulta');
    const guardar = document.getElementById('tsCrudGuardarBtn');
    const nuevo = document.getElementById('tsNuevoBtn');

    if (crearNuevo) ts_crudOrigenActualizacionPagina = false;
    nuevo?.classList.toggle('d-none', ts_crudOrigenActualizacionPagina);
    cuadros?.classList.remove('d-none');
    // La consulta SQL ahora vive en su propia vista SPA (sql-create).
    guardar?.classList.remove('d-none');

    if (crearNuevo && typeof ts_crudNuevo === 'function') {
        ts_crudNuevo();
    }
}

function ts_mostrarModoConsulta() {
    if (typeof showView === 'function') {
        showView('sql-create');
        document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => link.classList.remove('active'));
        document.querySelector('[data-view="sql-create"]')?.classList.add('active');
        const submenu = document.getElementById('consultasSqlSubmenu');
        const btn = document.getElementById('consultasSqlMenuBtn');
        submenu?.classList.remove('d-none');
        btn?.setAttribute('aria-expanded','true');
        btn?.classList.add('submenu-open');
    } else {
        document.getElementById('sql-create')?.classList.remove('d-none');
    }
    document.getElementById('tsModoConsulta')?.classList.remove('d-none');
    ts_sqlRestablecerEstadoConexion(false);
}

function ts_sqlRestablecerEstadoConexion(limpiarCampos = false) {
    ts_sqlConexionActiva = false;
    const estado = document.getElementById('tsSqlEstadoConexion');
    const consulta = document.getElementById('tsSqlConsulta');
    const verRegistros = document.getElementById('tsSqlVerRegistrosBtn');
    const guardarConsulta = document.getElementById('tsSqlGuardarBtn');
    const ayuda = document.getElementById('tsSqlAyuda');

    if (estado) {
        estado.textContent = 'Sin conexión';
        estado.className = 'badge text-bg-secondary';
    }
    if (consulta) consulta.disabled = true;
    if (verRegistros) verRegistros.disabled = true;
    if (guardarConsulta) guardarConsulta.disabled = true;
    if (ayuda) ayuda.textContent = 'Primero establezca la conexión.';

    if (limpiarCampos) {
        ['tsSqlNombreConexion','tsSqlServidor','tsSqlBase','tsSqlUsuario','tsSqlPassword','tsSqlConsulta']
            .forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });
        const motor = document.getElementById('tsSqlMotor');
        const puerto = document.getElementById('tsSqlPuerto');
        if (motor) motor.value = 'sqlserver';
        if (puerto) puerto.value = '1433';
    }
}

function ts_sqlPuertoPorMotor(motor) {
    return {
        sqlserver: '1433',
        postgresql: '5432',
        mysql: '3306',
        oracle: '1521'
    }[motor] || '';
}

function ts_sqlProbarConexion() {
    const servidor = document.getElementById('tsSqlServidor')?.value.trim();
    const base = document.getElementById('tsSqlBase')?.value.trim();
    const usuario = document.getElementById('tsSqlUsuario')?.value.trim();
    const motor = document.getElementById('tsSqlMotor')?.value || 'sqlserver';
    const estado = document.getElementById('tsSqlEstadoConexion');
    const consulta = document.getElementById('tsSqlConsulta');
    const verRegistros = document.getElementById('tsSqlVerRegistrosBtn');
    const guardarConsulta = document.getElementById('tsSqlGuardarBtn');
    const ayuda = document.getElementById('tsSqlAyuda');

    if (!servidor || !base || !usuario) {
        ts_sqlConexionActiva = false;
        if (estado) {
            estado.textContent = 'Datos incompletos';
            estado.className = 'badge text-bg-danger';
        }
        if (consulta) consulta.disabled = true;
        if (verRegistros) verRegistros.disabled = true;
        if (guardarConsulta) guardarConsulta.disabled = true;
        if (ayuda) ayuda.textContent = 'Capture servidor, base de datos y usuario para continuar.';
        return;
    }

    // Prototipo front-end: la conexión real debe ejecutarse mediante una API/backend.
    ts_sqlConexionActiva = true;
    if (estado) {
        estado.textContent = `Conectado · ${motor.toUpperCase()}`;
        estado.className = 'badge text-bg-success';
    }
    if (consulta) {
        consulta.disabled = false;
        if (!consulta.value.trim()) {
            consulta.value = 'SELECT TOP 100 *\nFROM CuadrosEstadisticos\nORDER BY FechaPeriodo DESC;';
        }
        consulta.focus();
    }
    if (verRegistros) verRegistros.disabled = false;
    if (guardarConsulta) guardarConsulta.disabled = false;
    if (ayuda) ayuda.textContent = 'Conexión validada. Escriba una consulta SELECT, guárdela o visualice los registros.';
}


function ts_sqlGuardarConsulta() {
    if (!ts_sqlConexionActiva) {
        ts_sqlProbarConexion();
        if (!ts_sqlConexionActiva) return;
    }

    const sql = document.getElementById('tsSqlConsulta')?.value.trim() || '';
    const ayuda = document.getElementById('tsSqlAyuda');

    if (!sql) {
        if (ayuda) ayuda.textContent = 'Escriba una consulta SQL antes de guardarla.';
        return;
    }

    const registro = {
        id: 'SQL-' + Date.now(),
        nombre: document.getElementById('tsSqlNombreConexion')?.value.trim() || 'Consulta SQL',
        motor: document.getElementById('tsSqlMotor')?.value || 'sqlserver',
        puerto: document.getElementById('tsSqlPuerto')?.value.trim() || '',
        servidor: document.getElementById('tsSqlServidor')?.value.trim() || '',
        baseDatos: document.getElementById('tsSqlBase')?.value.trim() || '',
        usuario: document.getElementById('tsSqlUsuario')?.value.trim() || '',
        consulta: sql,
        fechaActualizacion: new Date().toISOString()
    };

    // No se guarda la contraseña en localStorage.
    const clave = 'consultasSqlGuardadas';
    let registros = [];
    try {
        registros = JSON.parse(localStorage.getItem(clave) || '[]');
        if (!Array.isArray(registros)) registros = [];
    } catch (error) {
        registros = [];
    }

    const existente = registros.findIndex(item =>
        item.nombre === registro.nombre &&
        item.servidor === registro.servidor &&
        item.baseDatos === registro.baseDatos
    );

    if (existente >= 0) {
        registro.id = registros[existente].id;
        registros[existente] = registro;
    } else {
        registros.push(registro);
    }

    localStorage.setItem(clave, JSON.stringify(registros));

    if (window.PanelWebConsultas?.agregarDesdeCreador) {
        window.PanelWebConsultas.agregarDesdeCreador(registro);
    }

    if (ayuda) {
        ayuda.textContent = existente >= 0
            ? 'Consulta SQL actualizada correctamente.'
            : 'Consulta SQL guardada correctamente.';
    }
}

function ts_sqlVerRegistros() {
    const sql = document.getElementById('tsSqlConsulta')?.value.trim() || '';
    if (!ts_sqlConexionActiva) {
        ts_sqlProbarConexion();
        if (!ts_sqlConexionActiva) return;
    }
    if (!sql) {
        const ayuda = document.getElementById('tsSqlAyuda');
        if (ayuda) ayuda.textContent = 'Escriba una consulta SQL antes de visualizar los registros.';
        return;
    }
    if (!/^\s*(select|with)\b/i.test(sql)) {
        const ayuda = document.getElementById('tsSqlAyuda');
        if (ayuda) ayuda.textContent = 'Para este prototipo utilice una consulta de lectura (SELECT o WITH).';
        return;
    }

    const datos = ts_sqlDatosDemostracion(sql);
    ts_sqlRenderizarResultado(datos);
    bootstrap.Modal.getOrCreateInstance(document.getElementById('tsSqlRegistrosModal')).show();
}

function ts_sqlDatosDemostracion(sql) {
    // Datos ficticios para representar la respuesta que entregará la futura API.
    return [
        { id: 1001, periodo: '2026-06', afore: 'Azteca', concepto: 'Recursos administrados', valor: '79,995,325.40', estatus: 'Vigente' },
        { id: 1002, periodo: '2026-06', afore: 'Banamex', concepto: 'Recursos administrados', valor: '71,650,574.12', estatus: 'Vigente' },
        { id: 1003, periodo: '2026-06', afore: 'Coppel', concepto: 'Recursos administrados por tipo', valor: '17,894,216.08', estatus: 'Vigente' },
        { id: 1004, periodo: '2026-06', afore: 'Inbursa', concepto: 'Recursos administrados por tipo', valor: '8,946,721.55', estatus: 'Vigente' },
        { id: 1005, periodo: '2026-05', afore: 'Azteca', concepto: 'Recursos administrados', valor: '79,611,694.33', estatus: 'Vigente' }
    ];
}

function ts_sqlRenderizarResultado(registros) {
    const head = document.getElementById('tsSqlResultadoHead');
    const body = document.getElementById('tsSqlResultadoBody');
    const resumen = document.getElementById('tsSqlResumenResultado');
    if (!head || !body) return;

    const columnas = registros.length ? Object.keys(registros[0]) : [];
    head.innerHTML = `<tr>${columnas.map(c => `<th>${ts_sqlEscape(c)}</th>`).join('')}</tr>`;
    body.innerHTML = registros.length
        ? registros.map(r => `<tr>${columnas.map(c => `<td>${ts_sqlEscape(r[c])}</td>`).join('')}</tr>`).join('')
        : `<tr><td colspan="${Math.max(columnas.length,1)}" class="text-center text-muted py-4">Sin registros</td></tr>`;

    if (resumen) {
        const nombre = document.getElementById('tsSqlNombreConexion')?.value.trim() || 'Conexión actual';
        resumen.textContent = `${nombre} · ${registros.length} registro${registros.length === 1 ? '' : 's'} encontrados`;
    }
}

function ts_sqlEscape(valor) {
    return String(valor ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Ajusta automáticamente el puerto al cambiar el motor.
document.addEventListener('change', function (event) {
    if (event.target?.id === 'tsSqlMotor') {
        const puerto = document.getElementById('tsSqlPuerto');
        if (puerto) puerto.value = ts_sqlPuertoPorMotor(event.target.value);
        ts_sqlRestablecerEstadoConexion(false);
    }
});

// Si se modifica cualquier parámetro después de conectar, se obliga a validar otra vez.
document.addEventListener('input', function (event) {
    if (['tsSqlServidor','tsSqlBase','tsSqlUsuario','tsSqlPassword','tsSqlPuerto'].includes(event.target?.id) && ts_sqlConexionActiva) {
        ts_sqlRestablecerEstadoConexion(false);
    }
});


// ===== MENÚ NUEVO: control propio, independiente de Bootstrap =====
function ts_toggleNuevoMenu(event) {
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    const btn = document.getElementById('tsNuevoBtn');
    const menu = document.getElementById('tsNuevoMenu');
    if (!btn || !menu) return;

    const abierto = menu.classList.contains('show');
    ts_cerrarNuevoMenu();
    if (!abierto) {
        menu.classList.add('show');
        btn.setAttribute('aria-expanded', 'true');
    }
}

function ts_cerrarNuevoMenu() {
    const btn = document.getElementById('tsNuevoBtn');
    const menu = document.getElementById('tsNuevoMenu');
    if (menu) menu.classList.remove('show');
    if (btn) btn.setAttribute('aria-expanded', 'false');
}

document.addEventListener('click', function(event) {
    const contenedor = document.querySelector('#tables .ts-nuevo-dropdown');
    if (contenedor && !contenedor.contains(event.target)) {
        ts_cerrarNuevoMenu();
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') ts_cerrarNuevoMenu();
});


/* =========================================================
   VINCULACION: SERIES DE TIEMPO → CUADROS CONSUMIDORES
   ========================================================= */
function ts_vinculosSerieKey(id) {
    return String(id ?? "");
}

function ts_vinculosDepurar() {
    const idsSeries = new Set(ts_seriesDatos.map(s => ts_vinculosSerieKey(s.id)));
    Object.keys(ts_vinculosSeriesCuadros || {}).forEach(key => {
        if (!idsSeries.has(String(key))) delete ts_vinculosSeriesCuadros[key];
        else if (!Array.isArray(ts_vinculosSeriesCuadros[key])) ts_vinculosSeriesCuadros[key] = [];
    });
}

function ts_vinculosContarRegistro(registro) {
    const mapa = registro?.vinculosSeriesCuadros || {};
    return Object.values(mapa).reduce((total, ids) => total + (Array.isArray(ids) ? ids.length : 0), 0);
}

function ts_vinculosActualizarCatalogo() {
    const select = document.getElementById('tsVinculoSerie');
    const lista = document.getElementById('tsVinculoCuadrosLista');
    if (!select || !lista) return;

    ts_vinculosDepurar();
    const anterior = select.value;
    select.innerHTML = '<option value="">Seleccione una serie de tiempo...</option>';
    ts_seriesDatos.forEach(serie => {
        const op = document.createElement('option');
        op.value = String(serie.id);
        op.textContent = `${'— '.repeat(Number(serie.indent || 0))}${serie.title}`;
        select.appendChild(op);
    });
    if (ts_seriesDatos.some(s => String(s.id) === anterior)) select.value = anterior;
    else if (ts_seriesDatos.length === 1) select.value = String(ts_seriesDatos[0].id);

    ts_vinculosRenderCuadros();
    ts_vinculosRenderResumen();
}

let ts_vinculosPagina = 1;
const TS_VINCULOS_POR_PAGINA = 7;
let ts_vinculosPaginaIds = [];

function ts_vinculosAplicarFiltros() {
    ts_vinculosPagina = 1;
    ts_vinculosRenderCuadros();
}

function ts_vinculosObtenerRegistrosFiltrados(serieId) {
    const busqueda = String(document.getElementById('tsVinculoBuscarCuadro')?.value || '').trim().toLowerCase();
    const soloSeleccionados = !!document.getElementById('tsVinculoSoloSeleccionados')?.checked;
    const seleccionados = new Set((ts_vinculosSeriesCuadros[ts_vinculosSerieKey(serieId)] || []).map(String));

    return ts_crudLeerRegistros()
        .filter(r => r.id !== ts_crudIdActual)
        .filter(r => {
            if (soloSeleccionados && !seleccionados.has(String(r.id))) return false;
            if (!busqueda) return true;
            const texto = [
                r.id,
                r.titulo?.texto,
                r.configuracionSerie?.periodicidad
            ].map(v => String(v || '').toLowerCase()).join(' ');
            return texto.includes(busqueda);
        })
        .sort((a,b) => String(a.titulo?.texto || '').localeCompare(String(b.titulo?.texto || ''), 'es'));
}

function ts_vinculosCambiarPagina(pagina) {
    const numero = Number(pagina);
    if (!Number.isFinite(numero)) return;
    ts_vinculosPagina = Math.max(1, Math.floor(numero));
    ts_vinculosRenderCuadros();
}

function ts_vinculosSeleccionarPagina(checked) {
    const serieId = document.getElementById('tsVinculoSerie')?.value;
    if (!serieId || !ts_vinculosPaginaIds.length) return;
    const key = ts_vinculosSerieKey(serieId);
    const actuales = new Set((ts_vinculosSeriesCuadros[key] || []).map(String));
    ts_vinculosPaginaIds.forEach(id => checked ? actuales.add(String(id)) : actuales.delete(String(id)));
    ts_vinculosSeriesCuadros[key] = Array.from(actuales);
    ts_vinculosRenderCuadros();
    ts_vinculosRenderResumen();
}

function ts_vinculosRenderCuadros() {
    const select = document.getElementById('tsVinculoSerie');
    const lista = document.getElementById('tsVinculoCuadrosLista');
    const paginacion = document.getElementById('tsVinculoPaginacion');
    const resultados = document.getElementById('tsVinculoResultados');
    const contadorSeleccionados = document.getElementById('tsVinculoSeleccionados');
    if (!select || !lista) return;

    const serieId = select.value;
    ts_vinculosPaginaIds = [];
    if (!serieId) {
        lista.innerHTML = '<div class="ts-link-empty"><i class="bi bi-arrow-up-circle me-2"></i>Selecciona primero una serie de tiempo.</div>';
        if (paginacion) paginacion.classList.add('d-none');
        if (resultados) resultados.textContent = '0 cuadros';
        if (contadorSeleccionados) contadorSeleccionados.textContent = '0 seleccionados';
        return;
    }

    const seleccionados = new Set((ts_vinculosSeriesCuadros[ts_vinculosSerieKey(serieId)] || []).map(String));
    if (contadorSeleccionados) contadorSeleccionados.textContent = `${seleccionados.size} seleccionado${seleccionados.size === 1 ? '' : 's'}`;

    const todosDisponibles = ts_crudLeerRegistros().filter(r => r.id !== ts_crudIdActual);
    if (!todosDisponibles.length) {
        lista.innerHTML = '<div class="ts-link-empty"><i class="bi bi-inbox me-2"></i>No hay otros cuadros registrados disponibles para vincular.</div>';
        if (paginacion) paginacion.classList.add('d-none');
        if (resultados) resultados.textContent = '0 cuadros';
        return;
    }

    const registros = ts_vinculosObtenerRegistrosFiltrados(serieId);
    const totalPaginas = Math.max(1, Math.ceil(registros.length / TS_VINCULOS_POR_PAGINA));
    ts_vinculosPagina = Math.min(Math.max(1, ts_vinculosPagina), totalPaginas);
    const inicio = (ts_vinculosPagina - 1) * TS_VINCULOS_POR_PAGINA;
    const visibles = registros.slice(inicio, inicio + TS_VINCULOS_POR_PAGINA);
    ts_vinculosPaginaIds = visibles.map(r => String(r.id));

    if (resultados) {
        if (!registros.length) resultados.textContent = 'Sin coincidencias';
        else resultados.textContent = `${inicio + 1}–${inicio + visibles.length} de ${registros.length} cuadros`;
    }

    if (!visibles.length) {
        lista.innerHTML = '<div class="ts-link-empty"><i class="bi bi-search me-2"></i>No hay cuadros que coincidan con los filtros actuales.</div>';
    } else {
        lista.innerHTML = visibles.map(r => {
            const checked = seleccionados.has(String(r.id)) ? 'checked' : '';
            const periodicidad = r.configuracionSerie?.periodicidad || 'Sin periodicidad';
            return `
              <label class="ts-link-consumer ${checked ? 'is-linked' : ''}">
                <input type="checkbox" class="form-check-input" ${checked}
                       onchange="ts_vinculosToggle('${ts_escapeHtml(String(r.id))}', this.checked)">
                <span class="ts-link-consumer-main">
                  <span class="ts-link-consumer-title" title="${ts_escapeHtml(r.titulo?.texto || 'Sin título')}">${ts_escapeHtml(r.titulo?.texto || 'Sin título')}</span>
                  <span class="ts-link-consumer-meta"><span>${ts_escapeHtml(r.id)}</span><span>•</span><span>${ts_escapeHtml(periodicidad)}</span></span>
                </span>
                <span class="ts-link-state" title="${checked ? 'Vinculado' : 'Agregar vínculo'}"><i class="bi ${checked ? 'bi-link-45deg' : 'bi-plus-circle'}"></i></span>
              </label>`;
        }).join('');
    }

    if (paginacion) {
        if (totalPaginas <= 1) {
            paginacion.classList.add('d-none');
            paginacion.innerHTML = '';
        } else {
            paginacion.classList.remove('d-none');
            paginacion.innerHTML = `
              <button type="button" class="btn btn-outline-secondary btn-sm" ${ts_vinculosPagina <= 1 ? 'disabled' : ''}
                      onclick="ts_vinculosCambiarPagina(${ts_vinculosPagina - 1})" aria-label="Página anterior">
                <i class="bi bi-chevron-left"></i>
              </button>
              <span class="ts-link-page-status">Página <strong>${ts_vinculosPagina}</strong> de ${totalPaginas}</span>
              <button type="button" class="btn btn-outline-secondary btn-sm" ${ts_vinculosPagina >= totalPaginas ? 'disabled' : ''}
                      onclick="ts_vinculosCambiarPagina(${ts_vinculosPagina + 1})" aria-label="Página siguiente">
                <i class="bi bi-chevron-right"></i>
              </button>`;
        }
    }
}
function ts_vinculosToggle(cuadroId, checked) {
    const serieId = document.getElementById('tsVinculoSerie')?.value;
    if (!serieId) return;
    const key = ts_vinculosSerieKey(serieId);
    const actuales = new Set((ts_vinculosSeriesCuadros[key] || []).map(String));
    if (checked) actuales.add(String(cuadroId));
    else actuales.delete(String(cuadroId));
    ts_vinculosSeriesCuadros[key] = Array.from(actuales);
    ts_vinculosRenderCuadros();
    ts_vinculosRenderResumen();
}

function ts_vinculosRenderResumen() {
    const resumen = document.getElementById('tsVinculosResumen');
    const contador = document.getElementById('tsVinculosContador');
    if (!resumen) return;
    ts_vinculosDepurar();
    const catalogo = new Map(ts_crudLeerRegistros().map(r => [String(r.id), r]));
    let total = 0;
    const filas = ts_seriesDatos.map(serie => {
        const ids = (ts_vinculosSeriesCuadros[ts_vinculosSerieKey(serie.id)] || []).map(String);
        total += ids.length;
        if (!ids.length) return '';
        const destinos = ids.map(id => {
            const r = catalogo.get(id);
            return `<span class="badge ts-link-badge"><i class="bi bi-table me-1"></i>${ts_escapeHtml(r?.titulo?.texto || id)}</span>`;
        }).join('');
        return `<div class="ts-link-summary-row"><div><strong>${ts_escapeHtml(serie.title)}</strong><small>Serie de tiempo</small></div><div class="ts-link-summary-targets">${destinos}</div></div>`;
    }).filter(Boolean).join('');
    if (contador) contador.textContent = String(total);
    resumen.innerHTML = filas || '<div class="ts-link-empty"><i class="bi bi-link-45deg me-2"></i>Aún no hay vínculos configurados.</div>';
}

